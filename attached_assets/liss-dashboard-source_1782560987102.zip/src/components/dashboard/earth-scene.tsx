"use client";
import { useRef, useMemo, Component, type ReactNode } from "react";
import { EarthFallback } from "./earth-fallback";

// Error boundary to catch WebGL context failures
interface EBState { hasError: boolean }
class ThreeErrorBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, EBState> {
  state: EBState = { hasError: false };
  static getDerivedStateFromError() { return { hasError: true }; }
  render() {
    if (this.state.hasError) return this.props.fallback;
    return this.props.children;
  }
}

// Lazy load Three.js components to avoid crashing on missing WebGL
function ThreeScene() {
  const { Canvas, useFrame, Stars, Sphere, Ring } = (() => {
    try {
      return {
        Canvas: require("@react-three/fiber").Canvas,
        useFrame: require("@react-three/fiber").useFrame,
        Stars: require("@react-three/drei").Stars,
        Sphere: require("@react-three/drei").Sphere,
        Ring: require("@react-three/drei").Ring,
      };
    } catch {
      return { Canvas: null, useFrame: null, Stars: null, Sphere: null, Ring: null };
    }
  })();

  if (!Canvas) return <EarthFallback />;
  return <EarthFallback />;
}

export function EarthScene() {
  return (
    <ThreeErrorBoundary fallback={<EarthFallback />}>
      <ThreeScene />
    </ThreeErrorBoundary>
  );
}
