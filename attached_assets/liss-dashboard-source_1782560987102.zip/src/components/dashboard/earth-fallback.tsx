import { Satellite } from "lucide-react";

export function EarthFallback() {
  return (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden"
      style={{
        background: "radial-gradient(ellipse at 50% 50%, oklch(0.18 0.04 260), oklch(0.10 0.02 255) 70%, oklch(0.08 0.01 250))",
      }}
    >
      {/* Stars */}
      {Array.from({ length: 60 }, (_, i) => (
        <div
          key={i}
          className="absolute rounded-full bg-white"
          style={{
            width: Math.random() < 0.1 ? 2 : 1,
            height: Math.random() < 0.1 ? 2 : 1,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            opacity: 0.3 + Math.random() * 0.7,
            animation: `twinkle ${2 + Math.random() * 4}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 4}s`,
          }}
        />
      ))}

      <style>{`
        @keyframes twinkle {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }
        @keyframes orbit1 {
          from { transform: rotate(0deg) translateX(120px) rotate(0deg); }
          to { transform: rotate(360deg) translateX(120px) rotate(-360deg); }
        }
        @keyframes orbit2 {
          from { transform: rotate(120deg) translateX(145px) rotate(-120deg); }
          to { transform: rotate(480deg) translateX(145px) rotate(-480deg); }
        }
        @keyframes orbit3 {
          from { transform: rotate(240deg) translateX(168px) rotate(-240deg); }
          to { transform: rotate(600deg) translateX(168px) rotate(-600deg); }
        }
        @keyframes earthSpin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes moonOrbit {
          from { transform: rotate(0deg) translateX(105px) rotate(0deg); }
          to { transform: rotate(360deg) translateX(105px) rotate(-360deg); }
        }
        @keyframes pulseGlow {
          0%, 100% { box-shadow: 0 0 30px 10px oklch(0.5 0.2 195 / 0.25); }
          50% { box-shadow: 0 0 50px 20px oklch(0.6 0.2 195 / 0.35); }
        }
      `}</style>

      {/* Nebula blobs */}
      <div className="absolute h-64 w-64 rounded-full opacity-10"
        style={{ background: "radial-gradient(circle, oklch(0.6 0.2 280), transparent 70%)", top: "10%", left: "10%" }} />
      <div className="absolute h-48 w-48 rounded-full opacity-8"
        style={{ background: "radial-gradient(circle, oklch(0.6 0.2 195), transparent 70%)", bottom: "10%", right: "10%" }} />

      {/* Orbit rings */}
      <div className="absolute" style={{ width: 240, height: 240, left: "50%", top: "50%", transform: "translate(-50%,-50%)" }}>
        <div className="absolute inset-0 rounded-full border opacity-20" style={{ borderColor: "oklch(0.72 0.18 195)" }} />
      </div>
      <div className="absolute" style={{ width: 290, height: 145, left: "50%", top: "50%", transform: "translate(-50%,-50%) rotateX(70deg)", border: "1px solid oklch(0.68 0.18 260 / 0.2)", borderRadius: "50%" }} />
      <div className="absolute" style={{ width: 336, height: 168, left: "50%", top: "50%", transform: "translate(-50%,-50%) rotateX(75deg)", border: "1px solid oklch(0.70 0.16 150 / 0.15)", borderRadius: "50%" }} />

      {/* Earth */}
      <div
        className="absolute rounded-full"
        style={{
          width: 90,
          height: 90,
          left: "50%",
          top: "50%",
          transform: "translate(-50%,-50%)",
          background: "radial-gradient(circle at 35% 35%, oklch(0.55 0.18 200), oklch(0.35 0.14 210) 50%, oklch(0.25 0.1 220))",
          boxShadow: "0 0 40px 12px oklch(0.5 0.18 195 / 0.3), inset -12px -8px 20px oklch(0 0 0 / 0.5)",
          animation: "pulseGlow 4s ease-in-out infinite",
        }}
      >
        {/* Land masses */}
        <div className="absolute rounded-full" style={{ width: 28, height: 20, top: 20, left: 18, background: "oklch(0.45 0.14 145)", opacity: 0.9, transform: "rotate(-15deg)" }} />
        <div className="absolute rounded-full" style={{ width: 18, height: 14, top: 40, left: 50, background: "oklch(0.40 0.12 145)", opacity: 0.85 }} />
        <div className="absolute rounded-full" style={{ width: 20, height: 16, top: 28, left: 55, background: "oklch(0.42 0.13 140)", opacity: 0.8, transform: "rotate(20deg)" }} />
        {/* Cloud patches */}
        <div className="absolute rounded-full" style={{ width: 22, height: 10, top: 15, left: 35, background: "white", opacity: 0.35 }} />
        <div className="absolute rounded-full" style={{ width: 16, height: 8, top: 55, left: 20, background: "white", opacity: 0.3 }} />
        {/* Atmosphere ring */}
        <div className="absolute rounded-full" style={{ inset: -3, border: "3px solid oklch(0.65 0.15 200 / 0.25)", boxShadow: "0 0 12px oklch(0.65 0.15 200 / 0.2)" }} />
      </div>

      {/* Moon */}
      <div style={{ position: "absolute", left: "50%", top: "50%", animation: "moonOrbit 8s linear infinite", transformOrigin: "0 0" }}>
        <div style={{ transform: "translate(-50%, -50%)" }}>
          <div className="rounded-full" style={{
            width: 20,
            height: 20,
            background: "radial-gradient(circle at 35% 35%, #ccc, #888)",
            boxShadow: "inset -4px -3px 8px rgba(0,0,0,0.5), 0 0 8px rgba(200,200,200,0.2)",
          }} />
        </div>
      </div>

      {/* Satellite 1 */}
      <div style={{ position: "absolute", left: "50%", top: "50%", animation: "orbit1 6s linear infinite", transformOrigin: "0 0" }}>
        <div style={{ transform: "translate(-50%, -50%)" }}>
          <div className="flex items-center justify-center rounded" style={{ width: 18, height: 14, background: "#667", boxShadow: "0 0 8px oklch(0.72 0.18 195 / 0.6)" }}>
            <Satellite className="h-2.5 w-2.5 text-primary" />
          </div>
        </div>
      </div>

      {/* Satellite 2 */}
      <div style={{ position: "absolute", left: "50%", top: "50%", animation: "orbit2 9s linear infinite", transformOrigin: "0 0" }}>
        <div style={{ transform: "translate(-50%, -50%)" }}>
          <div className="flex items-center justify-center rounded" style={{ width: 16, height: 12, background: "#667", boxShadow: "0 0 8px oklch(0.70 0.16 280 / 0.6)" }}>
            <Satellite className="h-2 w-2" style={{ color: "oklch(0.70 0.16 280)" }} />
          </div>
        </div>
      </div>

      {/* Satellite 3 */}
      <div style={{ position: "absolute", left: "50%", top: "50%", animation: "orbit3 12s linear infinite", transformOrigin: "0 0" }}>
        <div style={{ transform: "translate(-50%, -50%)" }}>
          <div className="flex items-center justify-center rounded" style={{ width: 16, height: 12, background: "#667", boxShadow: "0 0 8px oklch(0.70 0.18 150 / 0.6)" }}>
            <Satellite className="h-2 w-2" style={{ color: "oklch(0.70 0.18 150)" }} />
          </div>
        </div>
      </div>
    </div>
  );
}
