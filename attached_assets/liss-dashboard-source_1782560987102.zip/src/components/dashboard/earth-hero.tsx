import { Suspense } from "react";
import { EarthScene } from "./earth-scene";
import { satelliteOrbits, stats } from "@/lib/mock-data";
import { Satellite, Signal, Globe } from "lucide-react";

function OrbitCard({ name, altitude, status, lat, lng }: { name: string; altitude: number; status: string; lat: number; lng: number }) {
  const isOp = status === "operational";
  return (
    <div className="flex items-center gap-2.5 rounded-lg border border-border/50 bg-card/60 px-3 py-2 backdrop-blur-sm">
      <div className={`h-2 w-2 rounded-full ${isOp ? "bg-success" : "bg-warning"} shadow-sm`} style={{ boxShadow: isOp ? "0 0 6px oklch(0.70 0.18 150)" : "0 0 6px oklch(0.80 0.16 85)" }} />
      <div className="min-w-0 flex-1">
        <div className="text-[11px] font-semibold leading-tight text-foreground">{name}</div>
        <div className="text-[10px] text-muted-foreground">{altitude} km · {lat.toFixed(1)}°N {lng.toFixed(1)}°E</div>
      </div>
      <Signal className="h-3.5 w-3.5 text-primary shrink-0" />
    </div>
  );
}

export function EarthHero() {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-card" style={{ minHeight: 380 }}>
      {/* Starfield background */}
      <div
        className="absolute inset-0"
        style={{
          background: "radial-gradient(ellipse at 50% 50%, oklch(0.15 0.03 260), oklch(0.10 0.02 255) 70%, oklch(0.08 0.01 250))",
        }}
      />

      {/* Subtle nebula overlays */}
      <div className="absolute inset-0 opacity-20" style={{
        background: "radial-gradient(ellipse at 20% 80%, oklch(0.4 0.12 280 / 0.4), transparent 50%), radial-gradient(ellipse at 80% 20%, oklch(0.4 0.12 195 / 0.3), transparent 50%)"
      }} />

      {/* Title overlay */}
      <div className="absolute left-5 top-5 z-10">
        <div className="flex items-center gap-2 mb-1">
          <Globe className="h-4 w-4 text-primary" />
          <span className="text-[11px] font-semibold uppercase tracking-widest text-primary">Live Orbital View</span>
        </div>
        <h2 className="text-xl font-bold text-gradient leading-tight">Satellite Tracking</h2>
        <p className="mt-0.5 text-xs text-muted-foreground">LISS-IV constellation · Real-time positions</p>
      </div>

      {/* Stats overlay top right */}
      <div className="absolute right-5 top-5 z-10 flex flex-col gap-1.5">
        <div className="rounded-lg border border-primary/20 bg-card/70 px-3 py-1.5 backdrop-blur-sm text-center">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Satellites</div>
          <div className="text-lg font-bold text-gradient">3</div>
        </div>
        <div className="rounded-lg border border-success/20 bg-card/70 px-3 py-1.5 backdrop-blur-sm text-center">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Passes Today</div>
          <div className="text-lg font-bold text-success">14</div>
        </div>
      </div>

      {/* Three.js Canvas */}
      <div className="absolute inset-0" style={{ height: "100%", width: "100%" }}>
        <Suspense fallback={
          <div className="flex h-full items-center justify-center">
            <div className="text-center">
              <div className="mx-auto mb-3 h-12 w-12 animate-spin rounded-full border-2 border-border border-t-primary" />
              <div className="text-xs text-muted-foreground">Rendering orbital scene...</div>
            </div>
          </div>
        }>
          <EarthScene />
        </Suspense>
      </div>

      {/* Satellite cards bottom */}
      <div className="absolute bottom-5 left-5 right-5 z-10 flex gap-2 overflow-x-auto">
        {satelliteOrbits.map((s) => (
          <div key={s.name} className="flex-1 min-w-40">
            <OrbitCard {...s} />
          </div>
        ))}
      </div>
    </div>
  );
}
