import { ArrowRight, Download, ZoomIn } from "lucide-react";

const SATELLITE_IMAGES = [
  {
    title: "Cloudy LISS-IV",
    badge: "INPUT",
    badgeColor: "bg-muted text-muted-foreground",
    subtitle: "Original capture · 42.3% cloud cover",
    url: "https://images.unsplash.com/photo-1569025743873-ea3a9ade89f9?w=400&h=400&fit=crop&auto=format",
    overlay: "radial-gradient(circle at 30% 40%, rgba(255,255,255,0.7), transparent 35%), radial-gradient(circle at 70% 60%, rgba(255,255,255,0.5), transparent 30%)",
  },
  {
    title: "Cloud Mask (U-Net)",
    badge: "MASK",
    badgeColor: "bg-primary/20 text-primary border border-primary/30",
    subtitle: "Binary segmentation · IoU 0.94",
    url: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=400&h=400&fit=crop&auto=format",
    overlay: "linear-gradient(135deg, oklch(0.72 0.18 195 / 0.4), oklch(0.68 0.18 260 / 0.3))",
  },
  {
    title: "Reconstructed",
    badge: "OUTPUT",
    badgeColor: "bg-success/20 text-success border border-success/30",
    subtitle: "Cloud-free output · PSNR 33.21 dB",
    url: "https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?w=400&h=400&fit=crop&auto=format",
    overlay: "",
  },
];

export function BeforeAfter() {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Before / After Preview</h3>
          <p className="text-xs text-muted-foreground">Scene SC-10247 · Brahmaputra Valley · 26 Jun 2026</p>
        </div>
        <div className="flex items-center gap-1">
          <button className="flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-[11px] text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
            <ZoomIn className="h-3 w-3" />
            View Full
          </button>
          <button className="flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-[11px] text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
            <Download className="h-3 w-3" />
            Export
          </button>
        </div>
      </div>

      <div className="flex items-stretch gap-3">
        {SATELLITE_IMAGES.map((img, i) => (
          <div key={i} className="flex flex-1 flex-col gap-2 min-w-0">
            {/* Badge */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-foreground">{img.title}</span>
              <span className={`rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${img.badgeColor}`}>{img.badge}</span>
            </div>

            {/* Image */}
            <div className="relative aspect-square w-full overflow-hidden rounded-xl border border-border group cursor-pointer">
              <img
                src={img.url}
                alt={img.title}
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
              {/* Overlay for mask effect */}
              {img.overlay && (
                <div className="absolute inset-0" style={{ background: img.overlay, mixBlendMode: "overlay" }} />
              )}
              {/* Scan line animation */}
              {i === 2 && (
                <div className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent opacity-80 animate-[scanline_3s_linear_infinite]" style={{ top: "50%" }} />
              )}
              {/* Hover overlay */}
              <div className="absolute inset-0 bg-background/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <ZoomIn className="h-6 w-6 text-white" />
              </div>
            </div>

            <span className="text-[11px] text-muted-foreground leading-tight">{img.subtitle}</span>

            {/* Arrow between panels */}
            {i < SATELLITE_IMAGES.length - 1 && (
              <></>
            )}
          </div>
        ))}
      </div>

      {/* Metadata bar */}
      <div className="mt-4 flex flex-wrap items-center gap-3 rounded-lg bg-muted/30 border border-border/50 px-3 py-2">
        {[
          ["Sensor", "LISS-IV MX"],
          ["Resolution", "5.8m"],
          ["Bands", "3B, 2, 1"],
          ["Date", "26 Jun 2026"],
          ["Orbit", "44,827"],
          ["Model", "U-Net v3.2"],
        ].map(([k, v]) => (
          <div key={k} className="flex items-center gap-1.5 text-[11px]">
            <span className="text-muted-foreground">{k}:</span>
            <span className="font-medium">{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
