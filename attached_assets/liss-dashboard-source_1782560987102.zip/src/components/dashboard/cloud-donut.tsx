import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from "recharts";
import { cloudDistribution } from "@/lib/mock-data";
import { Cloud } from "lucide-react";

const FILLS = [
  "oklch(0.70 0.18 150)",
  "oklch(0.72 0.18 195)",
  "oklch(0.80 0.16 85)",
  "oklch(0.70 0.16 280)",
  "oklch(0.68 0.18 25)",
];

export function CloudDonut() {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Cloud Cover Distribution</h3>
          <p className="text-xs text-muted-foreground">Across last 30 days of captures</p>
        </div>
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
          <Cloud className="h-4 w-4 text-primary" />
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Donut */}
        <div className="relative h-44 w-44 shrink-0">
          <ResponsiveContainer>
            <PieChart>
              <Pie
                data={cloudDistribution.map((d, i) => ({ ...d, fill: FILLS[i] }))}
                dataKey="value"
                nameKey="name"
                innerRadius={52}
                outerRadius={80}
                paddingAngle={3}
                strokeWidth={0}
              >
                {cloudDistribution.map((_, i) => (
                  <Cell
                    key={i}
                    fill={FILLS[i]}
                    style={{ filter: `drop-shadow(0 0 6px ${FILLS[i]}80)` }}
                  />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  background: "var(--color-popover)",
                  border: "1px solid var(--color-border)",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          {/* Center text */}
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-xl font-bold text-foreground">38.7%</span>
            <span className="text-[10px] text-muted-foreground">avg cover</span>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-1 flex-col gap-2.5">
          {cloudDistribution.map((d, i) => (
            <div key={d.name} className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-sm shrink-0" style={{ background: FILLS[i], boxShadow: `0 0 8px ${FILLS[i]}80` }} />
                <span className="text-xs text-muted-foreground">{d.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-1.5 w-16 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${d.value}%`, background: FILLS[i] }}
                  />
                </div>
                <span className="w-8 text-right text-xs font-semibold tabular-nums">{d.value}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
