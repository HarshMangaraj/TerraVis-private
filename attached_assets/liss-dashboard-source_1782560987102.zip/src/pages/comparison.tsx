import { useState, useRef } from "react";
import { Shell } from "@/components/layout/shell";
import { scenes } from "@/lib/mock-data";
import { GitCompare, ChevronDown, Maximize2, RefreshCw, Download, SlidersHorizontal, ZoomIn, ZoomOut } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  ResponsiveContainer, Tooltip,
} from "recharts";

const imagePairs = [
  {
    id: "SC-10247",
    name: "Brahmaputra Valley T44",
    before: "https://images.unsplash.com/photo-1446941611757-91d2c3bd3d45?w=800&q=85",
    after: "https://images.unsplash.com/photo-1508614999368-9260051292e5?w=800&q=85",
    metrics: { psnr: 33.21, ssim: 0.912, rmse: 7.84, cloudRemoved: 42.3, sharpness: 78, colorFidelity: 88 },
  },
  {
    id: "SC-10243",
    name: "Arunachal NE T55",
    before: "https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=800&q=85",
    after: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=800&q=85",
    metrics: { psnr: 36.89, ssim: 0.941, rmse: 4.91, cloudRemoved: 15.2, sharpness: 91, colorFidelity: 94 },
  },
  {
    id: "SC-10240",
    name: "Nagaland Central A12",
    before: "https://images.unsplash.com/photo-1532274402911-5a369e4c4bb5?w=800&q=85",
    after: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&q=85",
    metrics: { psnr: 34.18, ssim: 0.927, rmse: 6.44, cloudRemoved: 33.9, sharpness: 84, colorFidelity: 90 },
  },
];

export function ComparisonPage() {
  const [sceneA, setSceneA] = useState(0);
  const [sceneB, setSceneB] = useState(1);
  const [sliderPos, setSliderPos] = useState(50);
  const [mode, setMode] = useState<"slider" | "sidebyside" | "difference">("slider");
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    setSliderPos(Math.max(5, Math.min(95, x)));
  };

  const a = imagePairs[sceneA];
  const b = imagePairs[sceneB];

  const radarData = [
    { metric: "PSNR", A: (a.metrics.psnr / 40) * 100, B: (b.metrics.psnr / 40) * 100 },
    { metric: "SSIM", A: a.metrics.ssim * 100, B: b.metrics.ssim * 100 },
    { metric: "Sharpness", A: a.metrics.sharpness, B: b.metrics.sharpness },
    { metric: "Color", A: a.metrics.colorFidelity, B: b.metrics.colorFidelity },
    { metric: "Cloud%", A: 100 - a.metrics.cloudRemoved, B: 100 - b.metrics.cloudRemoved },
  ];

  return (
    <Shell title="Comparison" subtitle="Side-by-side scene comparison and quality analysis">
      <div className="space-y-5">

        {/* Scene selectors */}
        <div className="grid grid-cols-2 gap-4">
          {[{ label: "Scene A", idx: sceneA, setIdx: setSceneA, color: "text-primary border-primary/40 bg-primary/5" },
            { label: "Scene B", idx: sceneB, setIdx: setSceneB, color: "text-chart-2 border-chart-2/40 bg-chart-2/5" }
          ].map(({ label, idx, setIdx, color }) => (
            <div key={label} className={cn("relative rounded-xl border-2 p-3", color)}>
              <div className="mb-2 text-[10px] font-bold uppercase tracking-wider opacity-70">{label}</div>
              <select
                value={idx}
                onChange={(e) => setIdx(Number(e.target.value))}
                className="w-full rounded-lg border border-border bg-card/60 px-3 py-2 text-sm font-medium text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30"
              >
                {imagePairs.map((p, i) => (
                  <option key={p.id} value={i}>{p.id} — {p.name}</option>
                ))}
              </select>
            </div>
          ))}
        </div>

        {/* Mode selector */}
        <div className="flex items-center gap-2">
          {(["slider", "sidebyside", "difference"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={cn(
                "rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors capitalize",
                mode === m
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border bg-card text-muted-foreground hover:border-primary/50"
              )}
            >
              {m === "sidebyside" ? "Side by Side" : m === "difference" ? "Difference Map" : "Slider"}
            </button>
          ))}
          <div className="ml-auto flex items-center gap-2">
            <button className="flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground hover:border-primary hover:text-foreground transition-colors">
              <Download className="h-3.5 w-3.5" /> Export
            </button>
          </div>
        </div>

        {/* Viewer */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          {mode === "slider" && (
            <div
              ref={containerRef}
              className="relative h-80 cursor-col-resize select-none overflow-hidden"
              onMouseMove={handleMouseMove}
            >
              <img src={a.after} alt="After" className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}>
                <img src={a.before} alt="Before" className="h-full w-full object-cover" />
              </div>
              {/* Slider line */}
              <div className="absolute inset-y-0 w-0.5 bg-white shadow-[0_0_12px_rgba(255,255,255,0.8)]" style={{ left: `${sliderPos}%` }}>
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-full border-2 border-white bg-black/60 shadow-lg backdrop-blur-sm">
                  <SlidersHorizontal className="h-3.5 w-3.5 text-white" />
                </div>
              </div>
              {/* Labels */}
              <div className="absolute left-3 top-3 rounded-full border border-white/20 bg-black/50 px-2.5 py-1 text-xs font-semibold text-white backdrop-blur-sm">Before</div>
              <div className="absolute right-3 top-3 rounded-full border border-white/20 bg-black/50 px-2.5 py-1 text-xs font-semibold text-white backdrop-blur-sm">After</div>
            </div>
          )}

          {mode === "sidebyside" && (
            <div className="grid grid-cols-2 h-80">
              <div className="relative overflow-hidden border-r border-border">
                <img src={a.before} alt="Before" className="h-full w-full object-cover" />
                <div className="absolute left-3 top-3 rounded-full border border-white/20 bg-black/60 px-2.5 py-1 text-xs font-semibold text-white">Before · {a.id}</div>
              </div>
              <div className="relative overflow-hidden">
                <img src={a.after} alt="After" className="h-full w-full object-cover" />
                <div className="absolute left-3 top-3 rounded-full border border-white/20 bg-black/60 px-2.5 py-1 text-xs font-semibold text-white">After · {b.id}</div>
              </div>
            </div>
          )}

          {mode === "difference" && (
            <div className="relative h-80 flex items-center justify-center overflow-hidden"
              style={{ background: "oklch(0.12 0.04 260)" }}>
              <img src={a.after} alt="Diff" className="h-full w-full object-cover opacity-50 mix-blend-difference" />
              <img src={b.after} alt="Diff" className="absolute inset-0 h-full w-full object-cover opacity-50 mix-blend-difference" />
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-chart-2/10 mix-blend-color" />
              <div className="absolute bottom-3 left-3 rounded-full border border-white/20 bg-black/60 px-3 py-1 text-xs text-white">Difference map (pseudo-color)</div>
            </div>
          )}
        </div>

        {/* Metrics comparison */}
        <div className="grid grid-cols-5 gap-4">
          {/* Radar */}
          <div className="col-span-2 rounded-xl border border-border bg-card p-4">
            <div className="mb-2 text-sm font-semibold text-foreground">Quality Radar</div>
            <ResponsiveContainer width="100%" height={200}>
              <RadarChart data={radarData} margin={{ top: 10, right: 20, bottom: 10, left: 20 }}>
                <PolarGrid stroke="oklch(0.3 0.02 255 / 0.5)" />
                <PolarAngleAxis dataKey="metric" tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} />
                <PolarRadiusAxis angle={90} domain={[0, 100]} tick={false} axisLine={false} />
                <Radar name="Scene A" dataKey="A" stroke="oklch(0.72 0.18 195)" fill="oklch(0.72 0.18 195)" fillOpacity={0.2} strokeWidth={2} />
                <Radar name="Scene B" dataKey="B" stroke="oklch(0.75 0.18 160)" fill="oklch(0.75 0.18 160)" fillOpacity={0.15} strokeWidth={2} />
                <Tooltip contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} />
              </RadarChart>
            </ResponsiveContainer>
            <div className="flex items-center justify-center gap-4 mt-1">
              <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground"><span className="h-2 w-4 rounded-sm" style={{ background: "oklch(0.72 0.18 195)" }} />Scene A</span>
              <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground"><span className="h-2 w-4 rounded-sm" style={{ background: "oklch(0.75 0.18 160)" }} />Scene B</span>
            </div>
          </div>

          {/* Metric table */}
          <div className="col-span-3 rounded-xl border border-border bg-card overflow-hidden">
            <div className="border-b border-border px-4 py-3 text-sm font-semibold text-foreground">Metric Comparison</div>
            <table className="w-full">
              <thead>
                <tr className="border-b border-border/50 bg-muted/20">
                  <th className="px-4 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Metric</th>
                  <th className="px-4 py-2 text-center text-[10px] font-semibold uppercase tracking-wider text-primary">Scene A · {a.id}</th>
                  <th className="px-4 py-2 text-center text-[10px] font-semibold uppercase tracking-wider text-chart-2">Scene B · {b.id}</th>
                  <th className="px-4 py-2 text-center text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Winner</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {[
                  { label: "PSNR (dB)", va: a.metrics.psnr.toFixed(2), vb: b.metrics.psnr.toFixed(2), higherBetter: true, rawA: a.metrics.psnr, rawB: b.metrics.psnr },
                  { label: "SSIM", va: a.metrics.ssim.toFixed(3), vb: b.metrics.ssim.toFixed(3), higherBetter: true, rawA: a.metrics.ssim, rawB: b.metrics.ssim },
                  { label: "RMSE", va: a.metrics.rmse.toFixed(2), vb: b.metrics.rmse.toFixed(2), higherBetter: false, rawA: a.metrics.rmse, rawB: b.metrics.rmse },
                  { label: "Cloud Coverage", va: `${a.metrics.cloudRemoved}%`, vb: `${b.metrics.cloudRemoved}%`, higherBetter: false, rawA: a.metrics.cloudRemoved, rawB: b.metrics.cloudRemoved },
                  { label: "Sharpness", va: `${a.metrics.sharpness}/100`, vb: `${b.metrics.sharpness}/100`, higherBetter: true, rawA: a.metrics.sharpness, rawB: b.metrics.sharpness },
                  { label: "Color Fidelity", va: `${a.metrics.colorFidelity}/100`, vb: `${b.metrics.colorFidelity}/100`, higherBetter: true, rawA: a.metrics.colorFidelity, rawB: b.metrics.colorFidelity },
                ].map(({ label, va, vb, higherBetter, rawA, rawB }) => {
                  const winA = higherBetter ? rawA > rawB : rawA < rawB;
                  const winB = higherBetter ? rawB > rawA : rawB < rawA;
                  return (
                    <tr key={label} className="hover:bg-muted/10 transition-colors">
                      <td className="px-4 py-2.5 text-xs font-medium text-muted-foreground">{label}</td>
                      <td className={cn("px-4 py-2.5 text-center font-mono text-sm font-semibold", winA ? "text-primary" : "text-foreground")}>{va}</td>
                      <td className={cn("px-4 py-2.5 text-center font-mono text-sm font-semibold", winB ? "text-chart-2" : "text-foreground")}>{vb}</td>
                      <td className="px-4 py-2.5 text-center text-xs font-medium">
                        {winA && <span className="text-primary">A ↑</span>}
                        {winB && <span className="text-chart-2">B ↑</span>}
                        {!winA && !winB && <span className="text-muted-foreground">Tie</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </Shell>
  );
}
