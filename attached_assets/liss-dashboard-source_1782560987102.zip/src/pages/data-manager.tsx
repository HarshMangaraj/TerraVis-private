import { useState, useRef, useCallback } from "react";
import { Shell } from "@/components/layout/shell";
import { scenes, type Scene, type SceneStatus } from "@/lib/mock-data";
import {
  Upload, FolderOpen, Search, Filter, Download, Trash2,
  CloudOff, CheckCircle2, Clock, AlertCircle, X,
  Image, File, ChevronDown, MoreHorizontal, Eye,
} from "lucide-react";
import { cn } from "@/lib/utils";

const statusIcon: Record<SceneStatus, React.ReactNode> = {
  Completed: <CheckCircle2 className="h-3.5 w-3.5 text-success" />,
  Processing: <Clock className="h-3.5 w-3.5 text-warning animate-spin" />,
  Failed: <AlertCircle className="h-3.5 w-3.5 text-destructive" />,
  "In Queue": <Clock className="h-3.5 w-3.5 text-muted-foreground" />,
};

const statusColor: Record<SceneStatus, string> = {
  Completed: "text-success bg-success/10 border-success/20",
  Processing: "text-warning bg-warning/10 border-warning/20",
  Failed: "text-destructive bg-destructive/10 border-destructive/20",
  "In Queue": "text-muted-foreground bg-muted/30 border-border",
};

interface UploadFile {
  id: string;
  name: string;
  size: number;
  progress: number;
  status: "uploading" | "done" | "error";
  type: string;
}

export function DataManagerPage() {
  const [dragOver, setDragOver] = useState(false);
  const [uploads, setUploads] = useState<UploadFile[]>([]);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("All");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const fileInputRef = useRef<HTMLInputElement>(null);

  const simulateUpload = useCallback((files: File[]) => {
    const newUploads: UploadFile[] = files.map((f) => ({
      id: Math.random().toString(36).slice(2),
      name: f.name,
      size: f.size,
      progress: 0,
      status: "uploading" as const,
      type: f.type,
    }));
    setUploads((prev) => [...newUploads, ...prev]);

    newUploads.forEach((u) => {
      let prog = 0;
      const iv = setInterval(() => {
        prog += Math.random() * 18 + 5;
        if (prog >= 100) {
          prog = 100;
          clearInterval(iv);
          setUploads((prev) =>
            prev.map((f) => (f.id === u.id ? { ...f, progress: 100, status: "done" } : f))
          );
        } else {
          setUploads((prev) =>
            prev.map((f) => (f.id === u.id ? { ...f, progress: Math.round(prog) } : f))
          );
        }
      }, 200);
    });
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const files = Array.from(e.dataTransfer.files);
      if (files.length) simulateUpload(files);
    },
    [simulateUpload]
  );

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length) simulateUpload(files);
    e.target.value = "";
  };

  const removeUpload = (id: string) =>
    setUploads((prev) => prev.filter((f) => f.id !== id));

  const filteredScenes = scenes.filter((s) => {
    const matchSearch = search === "" || s.name.toLowerCase().includes(search.toLowerCase()) || s.id.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "All" || s.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  };

  const formatSize = (bytes: number) => {
    if (bytes > 1e6) return `${(bytes / 1e6).toFixed(1)} MB`;
    if (bytes > 1e3) return `${(bytes / 1e3).toFixed(0)} KB`;
    return `${bytes} B`;
  };

  return (
    <Shell title="Data Manager" subtitle="Ingest, catalog, and manage LISS-IV satellite imagery">
      <div className="space-y-5">

        {/* Upload zone */}
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={cn(
            "group relative flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed p-10 text-center transition-all duration-200",
            dragOver
              ? "border-primary bg-primary/5 shadow-[0_0_30px_oklch(0.72_0.18_195_/_0.2)]"
              : "border-border bg-card/50 hover:border-primary/50 hover:bg-primary/5"
          )}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".tif,.tiff,.jpg,.jpeg,.png,.hdf,.nc,.img"
            onChange={handleFileInput}
            className="hidden"
          />
          <div
            className={cn(
              "flex h-14 w-14 items-center justify-center rounded-2xl transition-colors",
              dragOver ? "bg-primary/20" : "bg-muted/50 group-hover:bg-primary/10"
            )}
          >
            <Upload className={cn("h-6 w-6 transition-colors", dragOver ? "text-primary" : "text-muted-foreground group-hover:text-primary")} />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground">
              {dragOver ? "Release to upload" : "Drop satellite imagery here or click to browse"}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Supports GeoTIFF · HDF5 · NetCDF · JPEG2000 · PNG · up to 10 GB per file
            </p>
          </div>
          <div className="mt-1 flex gap-3">
            <span
              onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
              className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1 text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary transition-colors"
            >
              <FolderOpen className="h-3 w-3" /> Browse files
            </span>
          </div>
        </div>

        {/* Active uploads */}
        {uploads.length > 0 && (
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="flex items-center justify-between border-b border-border px-4 py-2.5">
              <span className="text-xs font-semibold text-foreground">
                Uploads · {uploads.filter((u) => u.status === "done").length}/{uploads.length} done
              </span>
              <button
                onClick={() => setUploads([])}
                className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                Clear all
              </button>
            </div>
            <div className="divide-y divide-border">
              {uploads.map((u) => (
                <div key={u.id} className="flex items-center gap-3 px-4 py-2.5">
                  <div className={cn(
                    "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-xs",
                    u.type.startsWith("image") ? "bg-primary/10 text-primary" : "bg-muted/50 text-muted-foreground"
                  )}>
                    {u.type.startsWith("image") ? <Image className="h-4 w-4" /> : <File className="h-4 w-4" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-xs font-medium text-foreground">{u.name}</span>
                      <span className="shrink-0 text-[10px] text-muted-foreground">{formatSize(u.size)}</span>
                    </div>
                    <div className="mt-1.5 flex items-center gap-2">
                      <div className="relative h-1 flex-1 overflow-hidden rounded-full bg-muted">
                        <div
                          className={cn(
                            "absolute inset-y-0 left-0 rounded-full transition-all duration-200",
                            u.status === "done" ? "bg-success" : u.status === "error" ? "bg-destructive" : "bg-primary"
                          )}
                          style={{ width: `${u.progress}%` }}
                        />
                      </div>
                      <span className={cn(
                        "shrink-0 text-[10px] font-medium",
                        u.status === "done" ? "text-success" : u.status === "error" ? "text-destructive" : "text-muted-foreground"
                      )}>
                        {u.status === "done" ? "Done" : u.status === "error" ? "Error" : `${u.progress}%`}
                      </span>
                    </div>
                  </div>
                  <button onClick={() => removeUpload(u.id)} className="shrink-0 text-muted-foreground hover:text-foreground">
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-52">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search scenes by ID or name…"
              className="h-9 w-full rounded-lg border border-border bg-card/60 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary/30"
            />
          </div>
          <div className="flex items-center gap-2">
            {["All", "Completed", "Processing", "In Queue", "Failed"].map((s) => (
              <button
                key={s}
                onClick={() => setFilterStatus(s)}
                className={cn(
                  "rounded-full px-3 py-1.5 text-xs font-medium border transition-colors",
                  filterStatus === s
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-card/50 text-muted-foreground hover:border-primary/50 hover:text-foreground"
                )}
              >
                {s}
              </button>
            ))}
          </div>
          {selected.size > 0 && (
            <div className="ml-auto flex items-center gap-2">
              <span className="text-xs text-muted-foreground">{selected.size} selected</span>
              <button className="flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-medium text-foreground hover:border-primary transition-colors">
                <Download className="h-3.5 w-3.5" /> Export
              </button>
              <button
                onClick={() => setSelected(new Set())}
                className="flex items-center gap-1.5 rounded-lg border border-destructive/40 bg-destructive/5 px-3 py-1.5 text-xs font-medium text-destructive hover:bg-destructive/10 transition-colors"
              >
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </button>
            </div>
          )}
        </div>

        {/* Scene table */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="w-8 px-4 py-3">
                    <input
                      type="checkbox"
                      className="h-3.5 w-3.5 rounded accent-primary"
                      onChange={(e) => {
                        if (e.target.checked) setSelected(new Set(filteredScenes.map((s) => s.id)));
                        else setSelected(new Set());
                      }}
                      checked={selected.size === filteredScenes.length && filteredScenes.length > 0}
                    />
                  </th>
                  {["Scene ID", "Name", "Date", "Satellite", "Bands", "Cloud %", "PSNR", "Status", ""].map((h) => (
                    <th key={h} className="whitespace-nowrap px-3 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {filteredScenes.map((scene) => (
                  <tr
                    key={scene.id}
                    className={cn(
                      "group transition-colors hover:bg-muted/20",
                      selected.has(scene.id) && "bg-primary/5"
                    )}
                  >
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        className="h-3.5 w-3.5 rounded accent-primary"
                        checked={selected.has(scene.id)}
                        onChange={() => toggleSelect(scene.id)}
                      />
                    </td>
                    <td className="px-3 py-3 font-mono text-xs text-muted-foreground">{scene.id}</td>
                    <td className="px-3 py-3 font-medium text-foreground">{scene.name}</td>
                    <td className="px-3 py-3 text-xs text-muted-foreground">{scene.date}</td>
                    <td className="px-3 py-3 text-xs text-muted-foreground">{scene.satellite}</td>
                    <td className="px-3 py-3 text-xs font-mono text-muted-foreground">{scene.bands}</td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                        <div className="relative h-1 w-16 overflow-hidden rounded-full bg-muted">
                          <div
                            className={cn(
                              "absolute inset-y-0 left-0 rounded-full",
                              scene.cloudPct > 60 ? "bg-destructive" : scene.cloudPct > 30 ? "bg-warning" : "bg-success"
                            )}
                            style={{ width: `${scene.cloudPct}%` }}
                          />
                        </div>
                        <span className="text-xs tabular-nums text-foreground">{scene.cloudPct}%</span>
                      </div>
                    </td>
                    <td className="px-3 py-3 font-mono text-xs text-foreground">
                      {scene.psnr > 0 ? scene.psnr.toFixed(2) : "—"}
                    </td>
                    <td className="px-3 py-3">
                      <span className={cn(
                        "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-medium",
                        statusColor[scene.status]
                      )}>
                        {statusIcon[scene.status]} {scene.status}
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="rounded p-1 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                          <Eye className="h-3.5 w-3.5" />
                        </button>
                        <button className="rounded p-1 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                          <Download className="h-3.5 w-3.5" />
                        </button>
                        <button className="rounded p-1 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                          <MoreHorizontal className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between border-t border-border px-4 py-2.5 bg-muted/20">
            <span className="text-xs text-muted-foreground">
              Showing {filteredScenes.length} of {scenes.length} scenes
            </span>
            <div className="flex items-center gap-1">
              {[1, 2, 3, "…", 128].map((p, i) => (
                <button
                  key={i}
                  className={cn(
                    "flex h-7 w-7 items-center justify-center rounded text-xs transition-colors",
                    p === 1 ? "bg-primary/10 text-primary font-semibold" : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
}
