import { Shell } from "@/components/layout/shell";
import {
  Boxes, GitBranch, Tag, Upload, RotateCcw, Play,
  CheckCircle2, Clock, Archive, TrendingUp, Cpu,
  ChevronRight, MoreHorizontal, Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";

const models = [
  {
    name: "U-Net Cloud Detector",
    category: "Cloud Detection",
    version: "v3.2.1",
    status: "deployed",
    psnr: null,
    accuracy: 97.8,
    params: "7.76M",
    framework: "PyTorch 2.3",
    deployed: "2026-06-20",
    commits: 12,
    icon: "🌥️",
  },
  {
    name: "ResUNet Reconstructor",
    category: "Reconstruction",
    version: "v3.1.0",
    status: "deployed",
    psnr: 33.21,
    accuracy: null,
    params: "23.4M",
    framework: "PyTorch 2.3",
    deployed: "2026-06-15",
    commits: 8,
    icon: "🔭",
  },
  {
    name: "ML Fusion Network",
    category: "Fusion",
    version: "v1.4.2",
    status: "deployed",
    psnr: null,
    accuracy: 92.1,
    params: "11.2M",
    framework: "PyTorch 2.3",
    deployed: "2026-06-10",
    commits: 5,
    icon: "🔀",
  },
  {
    name: "DiffRecon Diffuser",
    category: "Reconstruction",
    version: "v0.8.0",
    status: "testing",
    psnr: 35.8,
    accuracy: null,
    params: "142M",
    framework: "PyTorch 2.3",
    deployed: null,
    commits: 3,
    icon: "🧪",
  },
  {
    name: "SwinIR Upscaler",
    category: "Post-processing",
    version: "v1.2.0",
    status: "candidate",
    psnr: 34.1,
    accuracy: null,
    params: "28.0M",
    framework: "PyTorch 2.3",
    deployed: null,
    commits: 2,
    icon: "⬆️",
  },
  {
    name: "U-Net Cloud Detector",
    category: "Cloud Detection",
    version: "v3.1.0",
    status: "archived",
    psnr: null,
    accuracy: 96.9,
    params: "7.76M",
    framework: "PyTorch 2.1",
    deployed: "2026-04-01",
    commits: 0,
    icon: "🌥️",
  },
];

const deployHistory = [
  { model: "U-Net v3.2.1", action: "Deployed to production", date: "2026-06-20", actor: "LA" },
  { model: "ResUNet v3.1.0", action: "Deployed to production", date: "2026-06-15", actor: "LA" },
  { model: "U-Net v3.1.0", action: "Archived", date: "2026-06-20", actor: "LA" },
  { model: "ML Fusion v1.4.2", action: "Deployed to production", date: "2026-06-10", actor: "LA" },
  { model: "DiffRecon v0.8.0", action: "Promoted to testing", date: "2026-06-25", actor: "LA" },
];

const statusStyle: Record<string, string> = {
  deployed: "bg-success/10 text-success border-success/25",
  testing: "bg-warning/10 text-warning border-warning/25",
  candidate: "bg-primary/10 text-primary border-primary/25",
  archived: "bg-muted/30 text-muted-foreground border-border",
};

const statusIcon: Record<string, React.ReactNode> = {
  deployed: <CheckCircle2 className="h-3 w-3" />,
  testing: <Clock className="h-3 w-3" />,
  candidate: <Zap className="h-3 w-3" />,
  archived: <Archive className="h-3 w-3" />,
};

export function ModelManagerPage() {
  return (
    <Shell title="Model Manager" subtitle="Version control and deployment for all AI models">
      <div className="space-y-5">

        {/* Summary */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Deployed Models", value: "3", color: "text-success" },
            { label: "In Testing", value: "1", color: "text-warning" },
            { label: "Candidates", value: "1", color: "text-primary" },
            { label: "Archived", value: "1", color: "text-muted-foreground" },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-border bg-card px-4 py-3 text-center">
              <div className={cn("text-3xl font-bold", s.color)}>{s.value}</div>
              <div className="mt-1 text-xs text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Model grid */}
        <div className="grid grid-cols-3 gap-4">
          {models.map((m) => (
            <div key={`${m.name}-${m.version}`} className={cn(
              "group rounded-xl border bg-card p-4 transition-all hover:border-primary/40",
              m.status === "deployed" ? "border-success/25" :
              m.status === "testing" ? "border-warning/25" :
              m.status === "archived" ? "border-border opacity-60" : "border-border"
            )}>
              <div className="mb-3 flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{m.icon}</span>
                  <div>
                    <div className="text-sm font-semibold text-foreground leading-tight">{m.name}</div>
                    <div className="text-[10px] text-muted-foreground">{m.category}</div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="flex items-center gap-1 rounded-full border border-border bg-muted/30 px-2 py-0.5 font-mono text-[10px] text-muted-foreground">
                    <Tag className="h-2.5 w-2.5" />{m.version}
                  </span>
                </div>
              </div>

              <div className="mb-3 grid grid-cols-2 gap-2">
                {[
                  { l: "Framework", v: m.framework },
                  { l: "Parameters", v: m.params },
                  { l: m.psnr ? "PSNR" : "Accuracy", v: m.psnr ? `${m.psnr} dB` : `${m.accuracy}%` },
                  { l: "Commits", v: m.commits.toString() },
                ].map(({ l, v }) => (
                  <div key={l} className="rounded-lg bg-muted/30 px-2 py-1.5">
                    <div className="text-[9px] text-muted-foreground">{l}</div>
                    <div className="text-[11px] font-semibold text-foreground">{v}</div>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <span className={cn(
                  "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                  statusStyle[m.status]
                )}>
                  {statusIcon[m.status]} {m.status}
                </span>
                {m.status !== "archived" && (
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {m.status === "testing" || m.status === "candidate" ? (
                      <button className="flex items-center gap-1 rounded-lg border border-success/30 bg-success/10 px-2 py-1 text-[10px] font-semibold text-success hover:bg-success/20 transition-colors">
                        <Play className="h-2.5 w-2.5" /> Deploy
                      </button>
                    ) : (
                      <button className="flex items-center gap-1 rounded-lg border border-border px-2 py-1 text-[10px] text-muted-foreground hover:border-primary hover:text-foreground transition-colors">
                        <RotateCcw className="h-2.5 w-2.5" /> Rollback
                      </button>
                    )}
                    <button className="rounded p-1 text-muted-foreground hover:text-foreground transition-colors">
                      <MoreHorizontal className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Deploy history */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="flex items-center gap-2 border-b border-border px-4 py-3">
            <GitBranch className="h-4 w-4 text-primary" />
            <span className="text-sm font-semibold text-foreground">Deployment History</span>
          </div>
          <div className="divide-y divide-border/50">
            {deployHistory.map((e, i) => (
              <div key={i} className="flex items-center gap-4 px-4 py-3 hover:bg-muted/10 transition-colors">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-border bg-muted/30 text-xs font-bold text-muted-foreground">
                  {e.actor}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-foreground">{e.action}</span>
                    <span className="rounded-full bg-primary/10 px-2 py-0.5 font-mono text-[10px] text-primary">{e.model}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">{e.date}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Shell>
  );
}
