import { Shell } from "@/components/layout/shell";
import { systemHealth } from "@/lib/mock-data";
import {
  Activity, CheckCircle2, AlertTriangle, XCircle, Bell,
  Server, Database, Cpu, HardDrive, Wifi, Clock, Filter,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer,
} from "recharts";
import { cn } from "@/lib/utils";

const logs = [
  { ts: "07:38:14", level: "INFO", service: "api-gateway", msg: "GET /api/scenes completed in 142ms" },
  { ts: "07:38:09", level: "INFO", service: "pipeline", msg: "Batch B-2205 started — 24 scenes" },
  { ts: "07:37:52", level: "WARN", service: "gpu-worker-2", msg: "GPU utilization at 96% — above threshold" },
  { ts: "07:37:41", level: "INFO", service: "reconstruction", msg: "JOB-4821 completed PSNR=33.2 dB" },
  { ts: "07:37:30", level: "INFO", service: "ingestion", msg: "Scene SC-10248 ingested from Sentinel feed" },
  { ts: "07:36:58", level: "ERROR", service: "gpu-worker-2", msg: "CUDA OOM error — job JOB-4816 requeued" },
  { ts: "07:36:44", level: "INFO", service: "cloud-detection", msg: "Model inference batch: 32 scenes in 384ms" },
  { ts: "07:36:21", level: "INFO", service: "object-storage", msg: "Exported 3 composites to S3 (2.4 GB)" },
  { ts: "07:36:10", level: "WARN", service: "queue-manager", msg: "Queue depth at 47 — consider scaling" },
  { ts: "07:35:48", level: "INFO", service: "api-gateway", msg: "POST /api/upload accepted — SC-10248" },
];

const uptimeSeries = Array.from({ length: 48 }, (_, i) => ({
  h: `${(i % 24).toString().padStart(2, "0")}:00`,
  latency: Math.floor(130 + Math.sin(i / 5) * 40 + Math.random() * 20),
  errors: Math.random() < 0.15 ? Math.floor(Math.random() * 5) : 0,
}));

const alerts = [
  { severity: "warning", title: "GPU Worker 2 high load", detail: "96% utilization · 23 min", time: "14m ago" },
  { severity: "info", title: "Queue depth elevated", detail: "47 jobs pending · threshold 40", time: "31m ago" },
  { severity: "resolved", title: "API Gateway latency spike", detail: "Resolved after 4 min", time: "2h ago" },
  { severity: "resolved", title: "Storage I/O bottleneck", detail: "Resolved — throttling lifted", time: "5h ago" },
];

const alertStyle: Record<string, string> = {
  warning: "border-warning/30 bg-warning/5 text-warning",
  error: "border-destructive/30 bg-destructive/5 text-destructive",
  info: "border-primary/30 bg-primary/5 text-primary",
  resolved: "border-success/30 bg-success/5 text-success",
};

const levelColor: Record<string, string> = {
  INFO: "text-primary bg-primary/10",
  WARN: "text-warning bg-warning/10",
  ERROR: "text-destructive bg-destructive/10",
};

export function MonitoringPage() {
  return (
    <Shell title="Monitoring" subtitle="Infrastructure health, live logs, and alerting">
      <div className="space-y-5">

        {/* Status overview */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "System Status", value: "Degraded", icon: AlertTriangle, color: "text-warning", subtext: "1 service degraded" },
            { label: "API Latency", value: "142ms", icon: Wifi, color: "text-primary", subtext: "p99: 312ms" },
            { label: "Uptime", value: "99.94%", icon: Activity, color: "text-success", subtext: "30-day rolling" },
            { label: "Active Alerts", value: "2", icon: Bell, color: "text-warning", subtext: "0 critical" },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-border bg-card px-4 py-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">{s.label}</span>
                <s.icon className={cn("h-4 w-4", s.color)} />
              </div>
              <div className={cn("text-2xl font-bold", s.color)}>{s.value}</div>
              <div className="mt-0.5 text-xs text-muted-foreground">{s.subtext}</div>
            </div>
          ))}
        </div>

        {/* Charts + alerts */}
        <div className="grid grid-cols-5 gap-4">
          {/* Latency chart */}
          <div className="col-span-3 rounded-xl border border-border bg-card p-4">
            <div className="mb-3 flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-foreground">API Latency — 48 Hours</span>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={uptimeSeries} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="gradLat" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.18 195)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.72 0.18 195)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 255 / 0.4)" vertical={false} />
                <XAxis dataKey="h" tick={{ fontSize: 9, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} interval={7} />
                <YAxis tick={{ fontSize: 9, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} formatter={(v) => [`${v}ms`, "Latency"]} />
                <Area type="monotone" dataKey="latency" stroke="oklch(0.72 0.18 195)" strokeWidth={2} fill="url(#gradLat)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Active alerts */}
          <div className="col-span-2 rounded-xl border border-border bg-card overflow-hidden">
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4 text-primary" />
                <span className="text-sm font-semibold text-foreground">Alerts</span>
              </div>
              <button className="text-xs text-muted-foreground hover:text-foreground transition-colors">Configure</button>
            </div>
            <div className="divide-y divide-border/50">
              {alerts.map((a, i) => (
                <div key={i} className={cn("border-l-2 px-4 py-3", alertStyle[a.severity].replace("border-", "border-l-").split(" ")[0])}>
                  <div className="flex items-start justify-between gap-2 mb-0.5">
                    <span className="text-xs font-semibold text-foreground">{a.title}</span>
                    <span className="shrink-0 text-[10px] text-muted-foreground">{a.time}</span>
                  </div>
                  <div className="text-[11px] text-muted-foreground">{a.detail}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Service health */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="flex items-center gap-2 border-b border-border px-4 py-3">
            <Server className="h-4 w-4 text-primary" />
            <span className="text-sm font-semibold text-foreground">Service Health</span>
          </div>
          <div className="grid grid-cols-2 gap-0 divide-y divide-border md:grid-cols-4 md:divide-y-0">
            {systemHealth.map((svc) => (
              <div key={svc.name} className={cn(
                "flex flex-col gap-1 border-r border-border px-4 py-3 last:border-r-0",
                svc.status === "degraded" && "bg-warning/5"
              )}>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-foreground">{svc.name}</span>
                  <span className={cn(
                    "h-2 w-2 rounded-full",
                    svc.status === "operational" ? "bg-success" : "bg-warning animate-pulse"
                  )} />
                </div>
                <span className="text-[10px] text-muted-foreground">{svc.detail}</span>
                <div className="mt-1 flex gap-0.5">
                  {Array.from({ length: 30 }, (_, i) => (
                    <div key={i} className={cn(
                      "h-3 flex-1 rounded-sm",
                      svc.status === "degraded" && i > 26
                        ? "bg-warning/70"
                        : Math.random() < 0.05 ? "bg-destructive/50" : "bg-success/60"
                    )} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Logs */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-foreground">Live Logs</span>
            </div>
            <div className="flex items-center gap-2">
              <button className="flex items-center gap-1.5 rounded-lg border border-border bg-card px-2.5 py-1 text-xs text-muted-foreground hover:border-primary hover:text-foreground transition-colors">
                <Filter className="h-3 w-3" /> Filter
              </button>
            </div>
          </div>
          <div className="divide-y divide-border/30 font-mono">
            {logs.map((log, i) => (
              <div key={i} className={cn(
                "flex items-start gap-3 px-4 py-2 text-[11px] hover:bg-muted/10 transition-colors",
                log.level === "ERROR" && "bg-destructive/5"
              )}>
                <span className="shrink-0 text-muted-foreground">{log.ts}</span>
                <span className={cn("shrink-0 rounded px-1.5 py-0.5 text-[9px] font-bold uppercase", levelColor[log.level] || "text-muted-foreground")}>
                  {log.level}
                </span>
                <span className="shrink-0 text-primary/70">[{log.service}]</span>
                <span className={cn("text-foreground/80", log.level === "ERROR" && "text-destructive")}>{log.msg}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Shell>
  );
}
