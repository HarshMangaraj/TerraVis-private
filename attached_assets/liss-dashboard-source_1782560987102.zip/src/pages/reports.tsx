import { Shell } from "@/components/layout/shell";
import { qualityMetrics, stats, statsDelta } from "@/lib/mock-data";
import {
  FileText, Download, Calendar, Filter, TrendingUp,
  CheckCircle2, CloudOff, Satellite, BarChart3,
  FileBarChart2, Share2, Printer,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar, Legend,
} from "recharts";
import { cn } from "@/lib/utils";

const reportTemplates = [
  { id: 1, title: "Weekly Processing Summary", desc: "Scene counts, cloud stats, throughput trends", icon: BarChart3, tags: ["weekly", "processing"] },
  { id: 2, title: "Quality Metrics Report", desc: "PSNR, SSIM, RMSE distribution analysis", icon: TrendingUp, tags: ["quality", "metrics"] },
  { id: 3, title: "Satellite Coverage Report", desc: "Geographic coverage and revisit frequency", icon: Satellite, tags: ["coverage", "geo"] },
  { id: 4, title: "Cloud Removal Efficacy", desc: "Before/after comparison with success rates", icon: CloudOff, tags: ["cloud", "efficacy"] },
  { id: 5, title: "Model Performance Audit", desc: "U-Net and reconstruction model benchmarks", icon: FileBarChart2, tags: ["model", "ai"] },
  { id: 6, title: "Monthly Executive Summary", desc: "High-level KPIs for stakeholder review", icon: FileText, tags: ["executive", "monthly"] },
];

const recentReports = [
  { title: "Weekly Processing Summary — W26 2026", date: "2026-06-27", size: "2.4 MB", format: "PDF" },
  { title: "Quality Metrics Report — Jun 2026", date: "2026-06-25", size: "1.8 MB", format: "XLSX" },
  { title: "Satellite Coverage Report — Jun 2026", date: "2026-06-20", size: "4.1 MB", format: "PDF" },
  { title: "Cloud Removal Efficacy — Q2 2026", date: "2026-06-15", size: "3.2 MB", format: "PDF" },
];

export function ReportsPage() {
  return (
    <Shell title="Reports" subtitle="Generate and export processing reports and analytics">
      <div className="space-y-5">

        {/* KPI summary */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Scenes Processed", value: "11,392", delta: "+12.4%", up: true, icon: CheckCircle2 },
            { label: "Avg Cloud Removed", value: "38.7%", delta: "-3.1%", up: false, icon: CloudOff },
            { label: "Mean PSNR", value: "32.84 dB", delta: "+1.2%", up: true, icon: TrendingUp },
            { label: "Success Rate", value: "97.8%", delta: "+0.3%", up: true, icon: CheckCircle2 },
          ].map((k) => (
            <div key={k.label} className="rounded-xl border border-border bg-card px-4 py-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">{k.label}</span>
                <k.icon className="h-3.5 w-3.5 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold text-foreground">{k.value}</div>
              <div className={cn("mt-0.5 text-xs font-medium", k.up ? "text-success" : "text-destructive")}>
                {k.delta} vs last period
              </div>
            </div>
          ))}
        </div>

        {/* Charts row */}
        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="mb-3 text-sm font-semibold text-foreground">PSNR Trend — 30 Days</div>
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={qualityMetrics} margin={{ top: 4, right: 4, bottom: 0, left: -22 }}>
                <defs>
                  <linearGradient id="rptPsnr" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.18 195)" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="oklch(0.72 0.18 195)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 255 / 0.4)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 9, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} interval={4} />
                <YAxis domain={[28, 38]} tick={{ fontSize: 9, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} />
                <Area type="monotone" dataKey="PSNR" stroke="oklch(0.72 0.18 195)" strokeWidth={2} fill="url(#rptPsnr)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="rounded-xl border border-border bg-card p-4">
            <div className="mb-3 text-sm font-semibold text-foreground">SSIM vs RMSE — 30 Days</div>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={qualityMetrics.filter((_, i) => i % 3 === 0)} margin={{ top: 4, right: 4, bottom: 0, left: -22 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 255 / 0.4)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 9, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 9, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} />
                <Bar dataKey="RMSE" fill="oklch(0.75 0.18 30)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="SSIM" fill="oklch(0.72 0.18 195)" radius={[3, 3, 0, 0]} />
                <Legend wrapperStyle={{ fontSize: 10, color: "oklch(0.6 0.02 255)" }} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Report templates */}
        <div>
          <div className="mb-3 flex items-center justify-between">
            <div className="text-sm font-semibold text-foreground">Report Templates</div>
            <div className="flex items-center gap-2">
              <button className="flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground hover:border-primary hover:text-foreground transition-colors">
                <Calendar className="h-3.5 w-3.5" /> Date Range
              </button>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {reportTemplates.map((r) => (
              <div key={r.id} className="group rounded-xl border border-border bg-card p-4 hover:border-primary/50 transition-colors">
                <div className="mb-3 flex items-start justify-between">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                    <r.icon className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex gap-1.5">
                    {r.tags.map((t) => (
                      <span key={t} className="rounded-full bg-muted/50 px-1.5 py-0.5 text-[9px] font-medium text-muted-foreground">{t}</span>
                    ))}
                  </div>
                </div>
                <div className="mb-1 text-sm font-semibold text-foreground leading-tight">{r.title}</div>
                <div className="mb-3 text-xs text-muted-foreground">{r.desc}</div>
                <div className="flex items-center gap-2">
                  <button className="flex-1 flex items-center justify-center gap-1.5 rounded-lg bg-primary/10 border border-primary/20 py-1.5 text-xs font-semibold text-primary hover:bg-primary/20 transition-colors">
                    <Download className="h-3 w-3" /> Generate PDF
                  </button>
                  <button className="flex items-center justify-center gap-1.5 rounded-lg border border-border bg-card p-1.5 text-xs text-muted-foreground hover:border-primary hover:text-foreground transition-colors">
                    <Share2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent reports */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="text-sm font-semibold text-foreground">Recent Reports</div>
            <button className="text-xs text-muted-foreground hover:text-foreground transition-colors">View all</button>
          </div>
          <div className="divide-y divide-border/50">
            {recentReports.map((r, i) => (
              <div key={i} className="flex items-center gap-4 px-4 py-3 hover:bg-muted/20 transition-colors group">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted/50">
                  <FileText className={cn("h-4 w-4", r.format === "PDF" ? "text-destructive" : "text-success")} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium text-foreground">{r.title}</div>
                  <div className="text-xs text-muted-foreground">{r.date} · {r.size} · {r.format}</div>
                </div>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="rounded p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"><Download className="h-3.5 w-3.5" /></button>
                  <button className="rounded p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"><Share2 className="h-3.5 w-3.5" /></button>
                  <button className="rounded p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"><Printer className="h-3.5 w-3.5" /></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Shell>
  );
}
