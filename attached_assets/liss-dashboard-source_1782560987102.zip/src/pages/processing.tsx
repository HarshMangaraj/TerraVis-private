import { useState } from "react";
import { Shell } from "@/components/layout/shell";
import { pipeline as pipelineStages, scenes } from "@/lib/mock-data";
import {
  Play, Pause, Square, RefreshCw, Settings2, Clock,
  Cpu, Zap, ChevronRight, AlertCircle, CheckCircle2,
  BarChart3, Layers,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";

const jobQueue = [
  { id: "JOB-4821", scene: "Brahmaputra_Valley_T44", stage: "Cloud Detection", gpu: "A100-1", eta: "2m 14s", progress: 73, priority: "high" },
  { id: "JOB-4820", scene: "Kaziranga_NP_R02", stage: "Reconstruction", gpu: "A100-2", eta: "5m 42s", progress: 38, priority: "normal" },
  { id: "JOB-4819", scene: "Mizoram_Hills_Q88", stage: "Pre-processing", gpu: "A100-1", eta: "0m 48s", progress: 91, priority: "normal" },
  { id: "JOB-4818", scene: "Nagaland_Central_A12", stage: "Fusion", gpu: "A100-3", eta: "8m 01s", progress: 12, priority: "low" },
  { id: "JOB-4817", scene: "Arunachal_NE_T55", stage: "Post-processing", gpu: "A100-2", eta: "1m 33s", progress: 82, priority: "high" },
];

const gpuMetrics = [
  { gpu: "A100-1", util: 87, vram: 72, temp: 68, jobs: 8 },
  { gpu: "A100-2", util: 94, vram: 85, temp: 74, jobs: 10 },
  { gpu: "A100-3", util: 61, vram: 55, temp: 62, jobs: 5 },
  { gpu: "A100-4", util: 0, vram: 12, temp: 41, jobs: 0, offline: true },
];

const throughputHistory = Array.from({ length: 20 }, (_, i) => ({
  t: `${i * 3}m`,
  ingested: Math.floor(40 + Math.sin(i / 3) * 12 + Math.random() * 8),
  processed: Math.floor(35 + Math.sin(i / 3 + 0.5) * 10 + Math.random() * 6),
}));

const priorityColor: Record<string, string> = {
  high: "text-destructive bg-destructive/10 border-destructive/20",
  normal: "text-primary bg-primary/10 border-primary/20",
  low: "text-muted-foreground bg-muted/40 border-border",
};

export function ProcessingPage() {
  const [paused, setPaused] = useState(false);
  const [batchSize, setBatchSize] = useState(32);
  const [workers, setWorkers] = useState(4);

  return (
    <Shell title="Processing" subtitle="Configure and monitor cloud detection pipelines">
      <div className="space-y-5">

        {/* Controls bar */}
        <div className="flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card px-4 py-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPaused(!paused)}
              className={cn(
                "flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors",
                paused
                  ? "bg-success/10 text-success border border-success/30 hover:bg-success/20"
                  : "bg-warning/10 text-warning border border-warning/30 hover:bg-warning/20"
              )}
            >
              {paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
              {paused ? "Resume Pipeline" : "Pause Pipeline"}
            </button>
            <button className="flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:border-primary transition-colors">
              <RefreshCw className="h-4 w-4" /> Restart Queue
            </button>
            <button className="flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors">
              <Square className="h-4 w-4" /> Stop All
            </button>
          </div>
          <div className="ml-auto flex items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className={cn("h-2 w-2 rounded-full", paused ? "bg-warning" : "bg-success animate-pulse")} />
              {paused ? "Paused" : "Running"}
            </span>
            <span>{jobQueue.length} active jobs</span>
            <span>847 scenes/hr</span>
          </div>
        </div>

        {/* Stage funnel */}
        <div className="grid grid-cols-7 gap-1 rounded-xl border border-border bg-card p-4">
          {pipelineStages.map((stage, i) => {
            const maxCount = pipelineStages[0].count;
            const pct = Math.round((stage.count / maxCount) * 100);
            return (
              <div key={stage.key} className="flex flex-col items-center gap-2">
                <div className="flex h-5 items-center">
                  {i < pipelineStages.length - 1 && (
                    <ChevronRight className="absolute translate-x-16 h-3 w-3 text-muted-foreground/40 hidden xl:block" />
                  )}
                </div>
                <div
                  className={cn(
                    "w-full rounded-lg flex items-end justify-center text-[10px] font-bold text-white transition-all",
                    i === pipelineStages.length - 1 ? "bg-success/80" : "bg-primary/70"
                  )}
                  style={{ height: `${Math.max(pct * 1.2, 24)}px` }}
                >
                  <span className="pb-1">{stage.count.toLocaleString()}</span>
                </div>
                <span className="text-center text-[10px] font-medium text-muted-foreground leading-tight">
                  {stage.label}
                </span>
              </div>
            );
          })}
        </div>

        {/* Main grid */}
        <div className="grid grid-cols-5 gap-4">

          {/* Job queue */}
          <div className="col-span-3 rounded-xl border border-border bg-card overflow-hidden">
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <div className="flex items-center gap-2">
                <Layers className="h-4 w-4 text-primary" />
                <span className="text-sm font-semibold text-foreground">Active Job Queue</span>
              </div>
              <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary">{jobQueue.length}</span>
            </div>
            <div className="divide-y divide-border/50">
              {jobQueue.map((job) => (
                <div key={job.id} className="px-4 py-3 hover:bg-muted/20 transition-colors group">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="font-mono text-[11px] text-muted-foreground shrink-0">{job.id}</span>
                      <span className="truncate text-sm font-medium text-foreground">{job.scene}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className={cn(
                        "rounded-full border px-2 py-0.5 text-[10px] font-medium",
                        priorityColor[job.priority]
                      )}>
                        {job.priority}
                      </span>
                      <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                        <Clock className="h-3 w-3" /> {job.eta}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex-1">
                      <div className="mb-1 flex items-center justify-between text-[10px]">
                        <span className="text-muted-foreground">{job.stage} · {job.gpu}</span>
                        <span className="font-medium text-foreground">{job.progress}%</span>
                      </div>
                      <div className="relative h-1.5 overflow-hidden rounded-full bg-muted">
                        <div
                          className="absolute inset-y-0 left-0 rounded-full bg-primary transition-all duration-500"
                          style={{ width: `${job.progress}%` }}
                        />
                      </div>
                    </div>
                    <button className="opacity-0 group-hover:opacity-100 rounded p-1 text-muted-foreground hover:text-destructive transition-all">
                      <Square className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right panel */}
          <div className="col-span-2 flex flex-col gap-4">

            {/* GPU utilization */}
            <div className="rounded-xl border border-border bg-card overflow-hidden">
              <div className="flex items-center gap-2 border-b border-border px-4 py-3">
                <Cpu className="h-4 w-4 text-primary" />
                <span className="text-sm font-semibold text-foreground">GPU Workers</span>
              </div>
              <div className="divide-y divide-border/50">
                {gpuMetrics.map((g) => (
                  <div key={g.gpu} className={cn("px-4 py-2.5", g.offline && "opacity-50")}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-medium text-foreground">{g.gpu}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-muted-foreground">{g.temp}°C</span>
                        <span className={cn(
                          "text-[10px] font-semibold",
                          g.offline ? "text-muted-foreground" : g.util > 90 ? "text-warning" : "text-success"
                        )}>
                          {g.offline ? "Offline" : `${g.util}%`}
                        </span>
                      </div>
                    </div>
                    {!g.offline && (
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="w-8 text-[9px] text-muted-foreground">GPU</span>
                          <div className="relative flex-1 h-1.5 overflow-hidden rounded-full bg-muted">
                            <div className={cn("absolute inset-y-0 left-0 rounded-full", g.util > 90 ? "bg-warning" : "bg-primary")} style={{ width: `${g.util}%` }} />
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-8 text-[9px] text-muted-foreground">VRAM</span>
                          <div className="relative flex-1 h-1.5 overflow-hidden rounded-full bg-muted">
                            <div className="absolute inset-y-0 left-0 rounded-full bg-chart-2" style={{ width: `${g.vram}%` }} />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Config */}
            <div className="rounded-xl border border-border bg-card overflow-hidden">
              <div className="flex items-center gap-2 border-b border-border px-4 py-3">
                <Settings2 className="h-4 w-4 text-primary" />
                <span className="text-sm font-semibold text-foreground">Pipeline Config</span>
              </div>
              <div className="space-y-3 p-4">
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <label className="text-xs font-medium text-muted-foreground">Batch Size</label>
                    <span className="text-xs font-semibold text-primary">{batchSize}</span>
                  </div>
                  <input
                    type="range" min={8} max={128} step={8}
                    value={batchSize}
                    onChange={(e) => setBatchSize(Number(e.target.value))}
                    className="w-full accent-[oklch(0.72_0.18_195)]"
                  />
                </div>
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <label className="text-xs font-medium text-muted-foreground">Workers</label>
                    <span className="text-xs font-semibold text-primary">{workers}</span>
                  </div>
                  <input
                    type="range" min={1} max={8} step={1}
                    value={workers}
                    onChange={(e) => setWorkers(Number(e.target.value))}
                    className="w-full accent-[oklch(0.72_0.18_195)]"
                  />
                </div>
                <div className="flex items-center justify-between pt-1">
                  <span className="text-xs text-muted-foreground">Auto-scale GPU</span>
                  <button className="relative h-5 w-9 rounded-full bg-primary transition-colors">
                    <span className="absolute right-0.5 top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform" />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Priority queue</span>
                  <button className="relative h-5 w-9 rounded-full bg-primary transition-colors">
                    <span className="absolute right-0.5 top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Throughput chart */}
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="mb-3 flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-primary" />
            <span className="text-sm font-semibold text-foreground">Throughput — Last 60 min</span>
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={throughputHistory} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="gradIngested" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.72 0.18 195)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.72 0.18 195)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradProcessedP" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.75 0.18 160)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.75 0.18 160)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 255 / 0.4)" vertical={false} />
              <XAxis dataKey="t" tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} />
              <Area type="monotone" dataKey="ingested" stroke="oklch(0.72 0.18 195)" strokeWidth={2} fill="url(#gradIngested)" name="Ingested" />
              <Area type="monotone" dataKey="processed" stroke="oklch(0.75 0.18 160)" strokeWidth={2} fill="url(#gradProcessedP)" name="Processed" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </Shell>
  );
}
