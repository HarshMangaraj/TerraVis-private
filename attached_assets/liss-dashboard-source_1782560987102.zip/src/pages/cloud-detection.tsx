import { Shell } from "@/components/layout/shell";
import {
  CloudOff, Cpu, TrendingUp, Zap, Play, RotateCcw,
  CheckCircle2, AlertCircle, BarChart3, Layers,
} from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, AreaChart, Area, Legend,
} from "recharts";
import { cn } from "@/lib/utils";

const trainingHistory = Array.from({ length: 40 }, (_, i) => ({
  epoch: i + 1,
  trainLoss: +(0.82 * Math.exp(-i / 12) + 0.08 + Math.random() * 0.02).toFixed(4),
  valLoss: +(0.85 * Math.exp(-i / 11) + 0.10 + Math.random() * 0.03).toFixed(4),
  iou: +(0.55 + (i / 40) * 0.32 + Math.random() * 0.01).toFixed(4),
  f1: +(0.58 + (i / 40) * 0.28 + Math.random() * 0.01).toFixed(4),
}));

const confusionMatrix = [
  { actual: "Cloud", predictedCloud: 9214, predictedClear: 421 },
  { actual: "Clear", predictedCloud: 178, predictedClear: 14187 },
];

const layerConfig = [
  { name: "Encoder Block 1", type: "Conv2D + BN + ReLU ×2", params: "38.4K", out: "256×256×64" },
  { name: "Encoder Block 2", type: "MaxPool + Conv2D ×2", params: "221K", out: "128×128×128" },
  { name: "Encoder Block 3", type: "MaxPool + Conv2D ×2", params: "885K", out: "64×64×256" },
  { name: "Bottleneck", type: "MaxPool + Conv2D ×2", params: "3.54M", out: "32×32×512" },
  { name: "Decoder Block 3", type: "UpConv + Skip + Conv2D ×2", params: "2.36M", out: "64×64×256" },
  { name: "Decoder Block 2", type: "UpConv + Skip + Conv2D ×2", params: "590K", out: "128×128×128" },
  { name: "Decoder Block 1", type: "UpConv + Skip + Conv2D ×2", params: "148K", out: "256×256×64" },
  { name: "Output", type: "Conv2D 1×1 + Sigmoid", params: "65", out: "256×256×1" },
];

export function CloudDetectionPage() {
  return (
    <Shell title="Cloud Detection" subtitle="U-Net model configuration and training metrics">
      <div className="space-y-5">

        {/* Model header */}
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-1">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                  <CloudOff className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="text-base font-bold text-foreground">U-Net Cloud Detector</div>
                  <div className="text-xs text-muted-foreground">v3.2.1 · Deployed · PyTorch 2.3</div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 mt-3">
                {[
                  { label: "IoU", value: "87.3%" },
                  { label: "F1 Score", value: "91.2%" },
                  { label: "Precision", value: "93.8%" },
                  { label: "Recall", value: "88.7%" },
                  { label: "Parameters", value: "7.76M" },
                  { label: "Inference", value: "12ms/img" },
                ].map((m) => (
                  <div key={m.label} className="rounded-lg border border-border bg-muted/30 px-3 py-1.5">
                    <div className="text-[10px] text-muted-foreground">{m.label}</div>
                    <div className="text-sm font-bold text-foreground">{m.value}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-xs font-medium text-muted-foreground hover:border-primary hover:text-foreground transition-colors">
                <RotateCcw className="h-3.5 w-3.5" /> Retrain
              </button>
              <button className="flex items-center gap-2 rounded-lg bg-primary/10 border border-primary/30 px-3 py-2 text-xs font-semibold text-primary hover:bg-primary/20 transition-colors">
                <Play className="h-3.5 w-3.5" /> Run Inference
              </button>
            </div>
          </div>
        </div>

        {/* Training charts */}
        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="mb-3 text-sm font-semibold text-foreground">Training Loss</div>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={trainingHistory} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 255 / 0.4)" vertical={false} />
                <XAxis dataKey="epoch" tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} label={{ value: "Epoch", position: "insideBottom", offset: -2, fontSize: 10, fill: "oklch(0.6 0.02 255)" }} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} />
                <Line type="monotone" dataKey="trainLoss" stroke="oklch(0.72 0.18 195)" strokeWidth={2} dot={false} name="Train Loss" />
                <Line type="monotone" dataKey="valLoss" stroke="oklch(0.75 0.18 30)" strokeWidth={2} dot={false} strokeDasharray="4 2" name="Val Loss" />
                <Legend wrapperStyle={{ fontSize: 10, color: "oklch(0.6 0.02 255)" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="mb-3 text-sm font-semibold text-foreground">IoU & F1 Score</div>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={trainingHistory} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="gradIou" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.18 195)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.72 0.18 195)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gradF1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.75 0.18 150)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.75 0.18 150)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 255 / 0.4)" vertical={false} />
                <XAxis dataKey="epoch" tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <YAxis domain={[0.5, 1]} tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} />
                <Area type="monotone" dataKey="iou" stroke="oklch(0.72 0.18 195)" strokeWidth={2} fill="url(#gradIou)" name="IoU" />
                <Area type="monotone" dataKey="f1" stroke="oklch(0.75 0.18 150)" strokeWidth={2} fill="url(#gradF1)" name="F1" />
                <Legend wrapperStyle={{ fontSize: 10, color: "oklch(0.6 0.02 255)" }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Confusion matrix + architecture */}
        <div className="grid grid-cols-5 gap-4">
          <div className="col-span-2 rounded-xl border border-border bg-card p-4">
            <div className="mb-3 text-sm font-semibold text-foreground">Confusion Matrix</div>
            <div className="space-y-2">
              <div className="grid grid-cols-3 gap-1">
                <div />
                <div className="text-center text-[10px] font-semibold text-muted-foreground">Pred: Cloud</div>
                <div className="text-center text-[10px] font-semibold text-muted-foreground">Pred: Clear</div>
              </div>
              {confusionMatrix.map((row) => (
                <div key={row.actual} className="grid grid-cols-3 gap-1">
                  <div className="flex items-center text-[10px] font-semibold text-muted-foreground">Act: {row.actual}</div>
                  <div className={cn(
                    "flex flex-col items-center justify-center rounded-lg py-3 text-center",
                    row.actual === "Cloud" ? "bg-primary/20 border border-primary/30" : "bg-muted/30 border border-border"
                  )}>
                    <div className={cn("text-lg font-bold", row.actual === "Cloud" ? "text-primary" : "text-muted-foreground")}>{row.predictedCloud.toLocaleString()}</div>
                    <div className="text-[9px] text-muted-foreground">{row.actual === "Cloud" ? "TP" : "FP"}</div>
                  </div>
                  <div className={cn(
                    "flex flex-col items-center justify-center rounded-lg py-3 text-center",
                    row.actual === "Clear" ? "bg-success/20 border border-success/30" : "bg-muted/30 border border-border"
                  )}>
                    <div className={cn("text-lg font-bold", row.actual === "Clear" ? "text-success" : "text-muted-foreground")}>{row.predictedClear.toLocaleString()}</div>
                    <div className="text-[9px] text-muted-foreground">{row.actual === "Clear" ? "TN" : "FN"}</div>
                  </div>
                </div>
              ))}
              <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                {[
                  { label: "Accuracy", value: "97.5%" },
                  { label: "Precision", value: "93.8%" },
                  { label: "Recall", value: "88.7%" },
                ].map((m) => (
                  <div key={m.label} className="rounded-lg bg-muted/30 py-2">
                    <div className="text-sm font-bold text-foreground">{m.value}</div>
                    <div className="text-[9px] text-muted-foreground">{m.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="col-span-3 rounded-xl border border-border bg-card overflow-hidden">
            <div className="border-b border-border px-4 py-3 text-sm font-semibold text-foreground">Model Architecture</div>
            <div className="divide-y divide-border/50">
              {layerConfig.map((layer, i) => (
                <div key={i} className="flex items-center gap-4 px-4 py-2.5 hover:bg-muted/10 transition-colors">
                  <div className={cn(
                    "flex h-6 w-6 shrink-0 items-center justify-center rounded text-[10px] font-bold",
                    layer.name.includes("Encoder") ? "bg-primary/15 text-primary" :
                    layer.name.includes("Decoder") ? "bg-chart-2/15 text-chart-2" :
                    layer.name === "Bottleneck" ? "bg-warning/15 text-warning" : "bg-success/15 text-success"
                  )}>
                    {i + 1}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-semibold text-foreground">{layer.name}</div>
                    <div className="text-[10px] text-muted-foreground">{layer.type}</div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-[11px] font-mono text-foreground">{layer.params}</div>
                    <div className="text-[9px] text-muted-foreground">{layer.out}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
}
