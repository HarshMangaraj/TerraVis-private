import { Shell } from "@/components/layout/shell";
import { Construction } from "lucide-react";

export function StubPage({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <Shell title={title} subtitle={subtitle}>
      <div className="flex h-full min-h-96 flex-col items-center justify-center gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-border bg-card">
          <Construction className="h-8 w-8 text-muted-foreground" />
        </div>
        <div className="text-center">
          <h2 className="text-lg font-semibold">{title}</h2>
          <p className="mt-1 text-sm text-muted-foreground">{subtitle || "This page is under construction"}</p>
        </div>
        <div className="mt-2 rounded-lg border border-primary/20 bg-primary/5 px-4 py-2 text-xs text-primary">
          Coming soon · LISS-IV AI Platform v2
        </div>
      </div>
    </Shell>
  );
}
