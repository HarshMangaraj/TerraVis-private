import { useState } from "react";
import { Shell } from "@/components/layout/shell";
import {
  Settings, User, Bell, Shield, Database, Satellite,
  Cpu, Globe, Key, Palette, Save, RefreshCw, Eye, EyeOff,
} from "lucide-react";
import { cn } from "@/lib/utils";

const tabs = [
  { id: "general", label: "General", icon: Settings },
  { id: "account", label: "Account", icon: User },
  { id: "notifications", label: "Notifications", icon: Bell },
  { id: "pipeline", label: "Pipeline", icon: Cpu },
  { id: "storage", label: "Storage & API", icon: Database },
  { id: "appearance", label: "Appearance", icon: Palette },
];

function Toggle({ defaultOn = false }: { defaultOn?: boolean }) {
  const [on, setOn] = useState(defaultOn);
  return (
    <button
      onClick={() => setOn(!on)}
      className={cn(
        "relative h-5 w-9 rounded-full transition-colors",
        on ? "bg-primary" : "bg-muted"
      )}
    >
      <span className={cn(
        "absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform",
        on ? "translate-x-4" : "translate-x-0.5"
      )} />
    </button>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      <div className="border-b border-border px-5 py-3">
        <div className="text-sm font-semibold text-foreground">{title}</div>
      </div>
      <div className="divide-y divide-border/50">{children}</div>
    </div>
  );
}

function Row({ label, desc, children }: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 px-5 py-3.5">
      <div>
        <div className="text-sm font-medium text-foreground">{label}</div>
        {desc && <div className="text-xs text-muted-foreground mt-0.5">{desc}</div>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function TextInput({ defaultValue, type = "text" }: { defaultValue?: string; type?: string }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <input
        type={type === "password" && !show ? "password" : "text"}
        defaultValue={defaultValue}
        className="h-8 w-56 rounded-lg border border-border bg-muted/30 px-3 pr-8 text-sm text-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary/30"
      />
      {type === "password" && (
        <button
          onClick={() => setShow(!show)}
          className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
        >
          {show ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
        </button>
      )}
    </div>
  );
}

export function SettingsPage() {
  const [activeTab, setActiveTab] = useState("general");

  return (
    <Shell title="Settings" subtitle="Platform configuration and user preferences">
      <div className="flex gap-6">
        {/* Tab nav */}
        <div className="w-44 shrink-0">
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex w-full items-center gap-2.5 border-b border-border/50 px-4 py-2.5 text-sm font-medium transition-colors last:border-b-0",
                  activeTab === tab.id
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted/30 hover:text-foreground"
                )}
              >
                <tab.icon className="h-3.5 w-3.5 shrink-0" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 space-y-4">
          {activeTab === "general" && (
            <>
              <Section title="Platform">
                <Row label="Platform Name" desc="Display name for the dashboard">
                  <TextInput defaultValue="LISS-IV AI Platform" />
                </Row>
                <Row label="Region" desc="Default geographic focus">
                  <select className="h-8 rounded-lg border border-border bg-muted/30 px-3 text-sm text-foreground focus:border-primary focus:outline-none">
                    <option>Northeast India</option>
                    <option>All India</option>
                    <option>South Asia</option>
                  </select>
                </Row>
                <Row label="Timezone" desc="Used for timestamp display">
                  <select className="h-8 rounded-lg border border-border bg-muted/30 px-3 text-sm text-foreground focus:border-primary focus:outline-none">
                    <option>IST (UTC+5:30)</option>
                    <option>UTC</option>
                    <option>EST</option>
                  </select>
                </Row>
                <Row label="Auto-refresh Dashboard" desc="Refresh metrics every 30 seconds">
                  <Toggle defaultOn />
                </Row>
              </Section>
              <Section title="Data">
                <Row label="Default Band Combination" desc="Band order for RGB composite">
                  <select className="h-8 rounded-lg border border-border bg-muted/30 px-3 text-sm text-foreground focus:border-primary focus:outline-none">
                    <option>3B, 2, 1 (Natural Color)</option>
                    <option>4, 3B, 2 (False Color)</option>
                    <option>4, 3B, 1 (Custom)</option>
                  </select>
                </Row>
                <Row label="Cloud Mask Threshold" desc="Minimum confidence for cloud masking">
                  <div className="flex items-center gap-2">
                    <input type="range" min={0} max={100} defaultValue={65} className="w-28 accent-[oklch(0.72_0.18_195)]" />
                    <span className="w-8 text-right text-sm font-semibold text-primary">65%</span>
                  </div>
                </Row>
                <Row label="Export Format" desc="Default file format for exports">
                  <select className="h-8 rounded-lg border border-border bg-muted/30 px-3 text-sm text-foreground focus:border-primary focus:outline-none">
                    <option>GeoTIFF</option>
                    <option>NetCDF</option>
                    <option>PNG</option>
                    <option>JPEG2000</option>
                  </select>
                </Row>
              </Section>
            </>
          )}

          {activeTab === "account" && (
            <Section title="Profile">
              <Row label="Full Name">
                <TextInput defaultValue="LISS-IV Admin" />
              </Row>
              <Row label="Email">
                <TextInput defaultValue="admin@isro.gov.in" type="text" />
              </Row>
              <Row label="Role" desc="Your access level">
                <span className="rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">Super Admin</span>
              </Row>
              <Row label="Password">
                <TextInput defaultValue="••••••••••" type="password" />
              </Row>
              <Row label="Two-Factor Auth" desc="Adds an extra layer of security">
                <Toggle />
              </Row>
            </Section>
          )}

          {activeTab === "notifications" && (
            <Section title="Alert Channels">
              <Row label="Email Alerts" desc="Send alerts to admin@isro.gov.in">
                <Toggle defaultOn />
              </Row>
              <Row label="Slack Webhook" desc="Post alerts to #liss-ops channel">
                <Toggle defaultOn />
              </Row>
              <Row label="SMS Alerts" desc="Critical failures only">
                <Toggle />
              </Row>
              <Row label="In-App Notifications">
                <Toggle defaultOn />
              </Row>
            </Section>
          )}

          {activeTab === "notifications" && (
            <Section title="Triggers">
              {[
                { label: "Job failure", desc: "Notify on any processing failure" },
                { label: "GPU load > 90%", desc: "Worker utilization alert" },
                { label: "Queue depth > 50", desc: "Queue backlog warning" },
                { label: "New batch completed", desc: "Notify on batch completion" },
                { label: "Model deployed", desc: "New model pushed to production" },
              ].map((n) => (
                <Row key={n.label} label={n.label} desc={n.desc}>
                  <Toggle defaultOn={n.label !== "New batch completed"} />
                </Row>
              ))}
            </Section>
          )}

          {activeTab === "pipeline" && (
            <Section title="Processing Defaults">
              <Row label="Batch Size" desc="Scenes per GPU batch">
                <div className="flex items-center gap-2">
                  <input type="range" min={8} max={128} step={8} defaultValue={32} className="w-28 accent-[oklch(0.72_0.18_195)]" />
                  <span className="w-8 text-right text-sm font-semibold text-primary">32</span>
                </div>
              </Row>
              <Row label="Parallel Workers" desc="Number of GPU workers">
                <select className="h-8 rounded-lg border border-border bg-muted/30 px-3 text-sm text-foreground focus:border-primary focus:outline-none">
                  {[2, 4, 6, 8].map((n) => <option key={n}>{n}</option>)}
                </select>
              </Row>
              <Row label="Auto-Retry Failed Jobs" desc="Retry up to 3 times on failure">
                <Toggle defaultOn />
              </Row>
              <Row label="Priority Queue" desc="High-priority scenes processed first">
                <Toggle defaultOn />
              </Row>
              <Row label="Auto-Scale GPU" desc="Add workers under heavy load">
                <Toggle />
              </Row>
            </Section>
          )}

          {activeTab === "storage" && (
            <Section title="Object Storage">
              <Row label="S3 Bucket" desc="Primary output storage bucket">
                <TextInput defaultValue="liss-iv-outputs" />
              </Row>
              <Row label="AWS Access Key">
                <TextInput defaultValue="AKIAIOSFODNN7EXAMPLE" type="password" />
              </Row>
              <Row label="AWS Region">
                <select className="h-8 rounded-lg border border-border bg-muted/30 px-3 text-sm text-foreground focus:border-primary focus:outline-none">
                  <option>ap-south-1 (Mumbai)</option>
                  <option>us-east-1</option>
                  <option>eu-west-1</option>
                </select>
              </Row>
            </Section>
          )}

          {activeTab === "storage" && (
            <Section title="Sentinel API">
              <Row label="ESA API Key">
                <TextInput defaultValue="••••••••••••••••••" type="password" />
              </Row>
              <Row label="Auto-Ingest" desc="Ingest new LISS-IV scenes automatically">
                <Toggle defaultOn />
              </Row>
            </Section>
          )}

          {activeTab === "appearance" && (
            <Section title="Theme">
              <Row label="Color Theme" desc="Dashboard color scheme">
                <select className="h-8 rounded-lg border border-border bg-muted/30 px-3 text-sm text-foreground focus:border-primary focus:outline-none">
                  <option>Space Dark (default)</option>
                  <option>Deep Navy</option>
                  <option>Midnight Green</option>
                </select>
              </Row>
              <Row label="Accent Color">
                <div className="flex items-center gap-2">
                  {["oklch(0.72 0.18 195)", "oklch(0.70 0.18 260)", "oklch(0.72 0.18 150)", "oklch(0.72 0.18 30)"].map((c) => (
                    <button key={c} className="h-6 w-6 rounded-full border-2 border-border hover:border-foreground transition-colors" style={{ background: c }} />
                  ))}
                </div>
              </Row>
              <Row label="Compact Mode" desc="Reduce padding and font sizes">
                <Toggle />
              </Row>
              <Row label="Show Earth Scene" desc="3D orbital view on dashboard">
                <Toggle defaultOn />
              </Row>
            </Section>
          )}

          {/* Save button */}
          <div className="flex items-center justify-end gap-3">
            <button className="flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium text-muted-foreground hover:border-primary hover:text-foreground transition-colors">
              <RefreshCw className="h-4 w-4" /> Reset
            </button>
            <button className="flex items-center gap-2 rounded-lg bg-primary/10 border border-primary/30 px-4 py-2 text-sm font-semibold text-primary hover:bg-primary/20 transition-colors">
              <Save className="h-4 w-4" /> Save Changes
            </button>
          </div>
        </div>
      </div>
    </Shell>
  );
}
