import { Shell } from "@/components/layout/shell";
import { Layers, Calendar, Clock, CheckCircle2, TrendingUp, Zap, Play, Settings2 } from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis,
} from "recharts";
import { cn } from "@/lib/utils";

const fusionJobs = [
  { id: "FUS-1122", scenes: ["SC-10247", "SC-10240", "SC-10238"], target: "Brahmaputra_Composite_Jun26", method: "Weighted Avg", count: 3, quality: 94, status: "completed" },
  { id: "FUS-1121", scenes: ["SC-10243", "SC-10242"], target: "Arunachal_Composite_Jun25", method: "Median Stack", count: 2, quality: 97, status: "completed" },
  { id: "FUS-1120", scenes: ["SC-10246", "SC-10241", "SC-10239", "SC-10237"], target: "Meghalaya_Composite_Jun24", method: "ML Fusion", count: 4, quality: 89, status: "processing" },
  { id: "FUS-1119", scenes: ["SC-10245", "SC-10244"], target: "Kaziranga_Composite_Jun24", method: "Weighted Avg", count: 2, quality: 0, status: "queued" },
];

const fusionQuality = Array.from({ length: 20 }, (_, i) => ({
  job: `FUS-${1100 + i}`,
  weighted: +(88 + Math.sin(i / 3) * 4 + Math.random() * 2).toFixed(1),
  median: +(85 + Math.cos(i / 4) * 5 + Math.random() * 2).toFixed(1),
  ml: +(91 + Math.sin(i / 2.5) * 3 + Math.random() * 1.5).toFixed(1),
}));

const radarData = [
  { axis: "Temporal Res.", weighted: 72, median: 65, ml: 88 },
  { axis: "Spatial Res.", weighted: 85, median: 80, ml: 91 },
  { axis: "Radiometry", weighted: 88, median: 83, ml: 92 },
  { axis: "Edge Preserv.", weighted: 79, median: 75, ml: 90 },
  { axis: "Cloud Robust.", weighted: 82, median: 90, ml: 95 },
  { axis: "Speed", weighted: 95, median: 92, ml: 58 },
];

const statusStyle: Record<string, string> = {
  completed: "bg-success/10 text-success border-success/25",
  processing: "bg-warning/10 text-warning border-warning/25",
  queued: "bg-muted/30 text-muted-foreground border-border",
  failed: "bg-destructive/10 text-destructive border-destructive/25",
};

export function FusionPage() {
  return (
    <Shell title="Fusion" subtitle="Multi-temporal image fusion pipeline for cloud-free composites">
      <div className="space-y-5">

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Composites Created", value: "2,847", icon: Layers, color: "text-primary" },
            { label: "Avg Scenes/Composite", value: "3.4", icon: Calendar, color: "text-chart-2" },
            { label: "Avg Quality Score", value: "92.1%", icon: TrendingUp, color: "text-success" },
            { label: "Avg Fusion Time", value: "4.2 min", icon: Clock, color: "text-warning" },
          ].map((s) => (
            <div key={s.label} className="flex items-center gap-3 rounded-xl border border-border bg-card px-4 py-3">
              <div className={cn("flex h-9 w-9 items-center justify-center rounded-lg bg-muted/50", s.color)}>
                <s.icon className="h-4.5 w-4.5" />
              </div>
              <div>
                <div className="text-lg font-bold text-foreground">{s.value}</div>
                <div className="text-[11px] text-muted-foreground">{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-5 gap-4">
          <div className="col-span-3 rounded-xl border border-border bg-card p-4">
            <div className="mb-3 text-sm font-semibold text-foreground">Quality by Fusion Method — Last 20 Jobs</div>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={fusionQuality} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                <defs>
                  {[
                    { id: "gW", c: "oklch(0.72 0.18 195)" },
                    { id: "gM", c: "oklch(0.75 0.18 30)" },
                    { id: "gML", c: "oklch(0.75 0.18 150)" },
                  ].map(({ id, c }) => (
                    <linearGradient key={id} id={id} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={c} stopOpacity={0.25} />
                      <stop offset="95%" stopColor={c} stopOpacity={0} />
                    </linearGradient>
                  ))}
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 255 / 0.4)" vertical={false} />
                <XAxis dataKey="job" tick={{ fontSize: 9, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} interval={4} />
                <YAxis domain={[75, 100]} tick={{ fontSize: 9, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} />
                <Area type="monotone" dataKey="weighted" stroke="oklch(0.72 0.18 195)" fill="url(#gW)" strokeWidth={2} name="Weighted Avg" />
                <Area type="monotone" dataKey="median" stroke="oklch(0.75 0.18 30)" fill="url(#gM)" strokeWidth={2} name="Median Stack" />
                <Area type="monotone" dataKey="ml" stroke="oklch(0.75 0.18 150)" fill="url(#gML)" strokeWidth={2} name="ML Fusion" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="col-span-2 rounded-xl border border-border bg-card p-4">
            <div className="mb-1 text-sm font-semibold text-foreground">Method Comparison</div>
            <ResponsiveContainer width="100%" height={200}>
              <RadarChart data={radarData} margin={{ top: 10, right: 20, bottom: 10, left: 20 }}>
                <PolarGrid stroke="oklch(0.3 0.02 255 / 0.5)" />
                <PolarAngleAxis dataKey="axis" tick={{ fontSize: 9, fill: "oklch(0.6 0.02 255)" }} />
                <PolarRadiusAxis angle={90} domain={[0, 100]} tick={false} axisLine={false} />
                <Radar name="Weighted" dataKey="weighted" stroke="oklch(0.72 0.18 195)" fill="oklch(0.72 0.18 195)" fillOpacity={0.15} strokeWidth={1.5} />
                <Radar name="Median" dataKey="median" stroke="oklch(0.75 0.18 30)" fill="oklch(0.75 0.18 30)" fillOpacity={0.1} strokeWidth={1.5} />
                <Radar name="ML" dataKey="ml" stroke="oklch(0.75 0.18 150)" fill="oklch(0.75 0.18 150)" fillOpacity={0.15} strokeWidth={2} />
                <Tooltip contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Job list */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="flex items-center gap-2">
              <Layers className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-foreground">Fusion Jobs</span>
            </div>
            <button className="flex items-center gap-2 rounded-lg bg-primary/10 border border-primary/20 px-3 py-1.5 text-xs font-semibold text-primary hover:bg-primary/20 transition-colors">
              <Play className="h-3.5 w-3.5" /> New Fusion Job
            </button>
          </div>
          <div className="divide-y divide-border/50">
            {fusionJobs.map((job) => (
              <div key={job.id} className="px-4 py-3 hover:bg-muted/20 transition-colors">
                <div className="flex items-center justify-between gap-3 mb-2">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-[11px] text-muted-foreground">{job.id}</span>
                    <span className="text-sm font-medium text-foreground">{job.target}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {job.quality > 0 && (
                      <span className="text-xs font-semibold text-success">Q: {job.quality}%</span>
                    )}
                    <span className={cn("rounded-full border px-2 py-0.5 text-[10px] font-semibold", statusStyle[job.status])}>
                      {job.status}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span>{job.count} input scenes</span>
                  <span>·</span>
                  <span className="text-primary font-medium">{job.method}</span>
                  <span>·</span>
                  <span>{job.scenes.join(", ")}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Shell>
  );
}
