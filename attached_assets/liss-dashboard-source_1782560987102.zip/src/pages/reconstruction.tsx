import { Shell } from "@/components/layout/shell";
import { Wand2, Play, Download, ChevronRight, TrendingUp, Layers } from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ScatterChart, Scatter, ZAxis, Legend,
} from "recharts";
import { cn } from "@/lib/utils";

const psnrHistory = Array.from({ length: 50 }, (_, i) => ({
  step: (i + 1) * 100,
  psnr: +(28 + (i / 50) * 7 + Math.sin(i / 5) * 0.8 + Math.random() * 0.3).toFixed(2),
  ssim: +(0.78 + (i / 50) * 0.16 + Math.random() * 0.01).toFixed(3),
}));

const scatterData = Array.from({ length: 60 }, (_, i) => ({
  cloud: Math.random() * 80 + 5,
  psnr: 38 - Math.random() * 8 - (Math.random() * 60) * 0.08,
  z: Math.random() * 20 + 10,
}));

const modelVariants = [
  { name: "ResUNet-v3.1 (prod)", psnr: 33.2, ssim: 0.921, params: "23.4M", latency: "28ms", status: "deployed" },
  { name: "DiffRecon-v0.8 (beta)", psnr: 35.8, ssim: 0.944, params: "142M", latency: "310ms", status: "testing" },
  { name: "SwinIR-v1.2", psnr: 34.1, ssim: 0.931, params: "28.0M", latency: "45ms", status: "candidate" },
  { name: "ResUNet-v3.0 (prev)", psnr: 31.9, ssim: 0.908, params: "23.4M", latency: "27ms", status: "retired" },
];

const statusStyle: Record<string, string> = {
  deployed: "bg-success/10 text-success border-success/25",
  testing: "bg-warning/10 text-warning border-warning/25",
  candidate: "bg-primary/10 text-primary border-primary/25",
  retired: "bg-muted/30 text-muted-foreground border-border",
};

export function ReconstructionPage() {
  return (
    <Shell title="Reconstruction" subtitle="Deep learning reconstruction model management and benchmarks">
      <div className="space-y-5">

        {/* Model cards */}
        <div className="grid grid-cols-4 gap-3">
          {modelVariants.map((m) => (
            <div key={m.name} className={cn(
              "rounded-xl border-2 bg-card p-4 transition-all",
              m.status === "deployed" ? "border-success/30" : m.status === "testing" ? "border-warning/30" : "border-border"
            )}>
              <div className="mb-3 flex items-start justify-between gap-1">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                  <Wand2 className="h-4 w-4 text-primary" />
                </div>
                <span className={cn("rounded-full border px-2 py-0.5 text-[10px] font-semibold", statusStyle[m.status])}>
                  {m.status}
                </span>
              </div>
              <div className="mb-3 text-xs font-semibold leading-tight text-foreground">{m.name}</div>
              <div className="space-y-1.5">
                {[
                  { l: "PSNR", v: `${m.psnr} dB` },
                  { l: "SSIM", v: m.ssim.toString() },
                  { l: "Params", v: m.params },
                  { l: "Latency", v: m.latency },
                ].map(({ l, v }) => (
                  <div key={l} className="flex items-center justify-between text-[11px]">
                    <span className="text-muted-foreground">{l}</span>
                    <span className="font-semibold text-foreground">{v}</span>
                  </div>
                ))}
              </div>
              {m.status !== "retired" && (
                <button className="mt-3 w-full rounded-lg bg-primary/10 border border-primary/20 py-1.5 text-[11px] font-semibold text-primary hover:bg-primary/20 transition-colors">
                  {m.status === "deployed" ? "View Details" : "Promote to Prod"}
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="mb-3 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-foreground">PSNR / SSIM Training Curves</span>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={psnrHistory} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 255 / 0.4)" vertical={false} />
                <XAxis dataKey="step" tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
                <YAxis yAxisId="left" domain={[26, 38]} tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <YAxis yAxisId="right" orientation="right" domain={[0.75, 1]} tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} />
                <Line yAxisId="left" type="monotone" dataKey="psnr" stroke="oklch(0.72 0.18 195)" strokeWidth={2} dot={false} name="PSNR (dB)" />
                <Line yAxisId="right" type="monotone" dataKey="ssim" stroke="oklch(0.75 0.18 150)" strokeWidth={2} dot={false} name="SSIM" />
                <Legend wrapperStyle={{ fontSize: 10, color: "oklch(0.6 0.02 255)" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="rounded-xl border border-border bg-card p-4">
            <div className="mb-3 flex items-center gap-2">
              <Layers className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-foreground">Cloud Coverage vs PSNR</span>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <ScatterChart margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.02 255 / 0.4)" />
                <XAxis dataKey="cloud" name="Cloud %" unit="%" tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <YAxis dataKey="psnr" name="PSNR" unit=" dB" domain={[24, 40]} tick={{ fontSize: 10, fill: "oklch(0.6 0.02 255)" }} axisLine={false} tickLine={false} />
                <ZAxis dataKey="z" range={[20, 80]} />
                <Tooltip cursor={{ strokeDasharray: "3 3" }} contentStyle={{ background: "oklch(0.18 0.04 255)", border: "1px solid oklch(0.3 0.04 255)", borderRadius: 8, fontSize: 11 }} />
                <Scatter data={scatterData} fill="oklch(0.72 0.18 195)" fillOpacity={0.6} />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sample outputs */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="text-sm font-semibold text-foreground">Sample Reconstruction Outputs</div>
            <button className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
              View all <ChevronRight className="h-3 w-3" />
            </button>
          </div>
          <div className="grid grid-cols-4 divide-x divide-border">
            {[
              { label: "Input (cloudy)", src: "https://images.unsplash.com/photo-1446941611757-91d2c3bd3d45?w=400&q=80", tag: "Cloud: 42.3%" },
              { label: "Cloud Mask", src: "https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=400&q=80", tag: "Binary mask" },
              { label: "Reconstructed", src: "https://images.unsplash.com/photo-1508614999368-9260051292e5?w=400&q=80", tag: "PSNR: 33.2 dB" },
              { label: "Ground Truth", src: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=400&q=80", tag: "Reference" },
            ].map((img) => (
              <div key={img.label} className="relative">
                <img src={img.src} alt={img.label} className="h-40 w-full object-cover" />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-2">
                  <div className="text-[10px] font-semibold text-white">{img.label}</div>
                  <div className="text-[9px] text-white/70">{img.tag}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Shell>
  );
}
