import { useState } from "react";
import { Shell } from "@/components/layout/shell";
import { scenes } from "@/lib/mock-data";
import {
  Grid3X3, List, Download, Filter, Eye, Star,
  CheckCircle2, SlidersHorizontal, ArrowUpDown,
  CloudOff, Image as ImageIcon, ZoomIn,
} from "lucide-react";
import { cn } from "@/lib/utils";

const beforeAfterPairs = [
  {
    id: "SC-10247",
    name: "Brahmaputra Valley T44",
    date: "2026-06-26",
    cloudBefore: 42.3,
    psnr: 33.21,
    ssim: 0.912,
    before: "https://images.unsplash.com/photo-1446941611757-91d2c3bd3d45?w=600&q=80",
    after: "https://images.unsplash.com/photo-1508614999368-9260051292e5?w=600&q=80",
    satellite: "LISS-IV MX",
    starred: true,
  },
  {
    id: "SC-10243",
    name: "Arunachal NE T55",
    date: "2026-06-25",
    cloudBefore: 15.2,
    psnr: 36.89,
    ssim: 0.941,
    before: "https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=600&q=80",
    after: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=600&q=80",
    satellite: "LISS-IV MX",
    starred: false,
  },
  {
    id: "SC-10240",
    name: "Nagaland Central A12",
    date: "2026-06-24",
    cloudBefore: 33.9,
    psnr: 34.18,
    ssim: 0.927,
    before: "https://images.unsplash.com/photo-1532274402911-5a369e4c4bb5?w=600&q=80",
    after: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&q=80",
    satellite: "LISS-IV MX",
    starred: true,
  },
  {
    id: "SC-10238",
    name: "Manas Reserve K33",
    date: "2026-06-23",
    cloudBefore: 28.1,
    psnr: 35.02,
    ssim: 0.935,
    before: "https://images.unsplash.com/photo-1549490349-8643362247b5?w=600&q=80",
    after: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&q=80",
    satellite: "LISS-IV MONO",
    starred: false,
  },
  {
    id: "SC-10242",
    name: "Tripura South F19",
    date: "2026-06-25",
    cloudBefore: 54.8,
    psnr: 31.42,
    ssim: 0.893,
    before: "https://images.unsplash.com/photo-1534430480872-3498386e7856?w=600&q=80",
    after: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=600&q=80",
    satellite: "LISS-IV MONO",
    starred: false,
  },
  {
    id: "SC-10246",
    name: "Shillong Plateau E18",
    date: "2026-06-26",
    cloudBefore: 68.1,
    psnr: 29.14,
    ssim: 0.871,
    before: "https://images.unsplash.com/photo-1503614472-8c93d56e92ce?w=600&q=80",
    after: "https://images.unsplash.com/photo-1523712999610-f77fbcfc3843?w=600&q=80",
    satellite: "LISS-IV MONO",
    starred: false,
  },
];

export function ResultsPage() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [starred, setStarred] = useState<Set<string>>(
    new Set(beforeAfterPairs.filter((p) => p.starred).map((p) => p.id))
  );
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const toggleStar = (id: string) =>
    setStarred((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  return (
    <Shell title="Results" subtitle="Browse cloud-removed reconstruction outputs and export datasets">
      <div className="space-y-5">

        {/* Summary */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Total Outputs", value: "10,854", icon: ImageIcon, color: "text-primary" },
            { label: "Avg PSNR", value: "32.84 dB", icon: CheckCircle2, color: "text-success" },
            { label: "Avg SSIM", value: "0.913", icon: CheckCircle2, color: "text-chart-2" },
            { label: "Exported Today", value: "428", icon: Download, color: "text-warning" },
          ].map((s) => (
            <div key={s.label} className="flex items-center gap-3 rounded-xl border border-border bg-card px-4 py-3">
              <div className={cn("flex h-9 w-9 items-center justify-center rounded-lg bg-muted/50", s.color)}>
                <s.icon className="h-4.5 w-4.5" />
              </div>
              <div>
                <div className="text-lg font-bold text-foreground">{s.value}</div>
                <div className="text-[11px] text-muted-foreground">{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 rounded-lg border border-border bg-card p-1">
            <button
              onClick={() => setViewMode("grid")}
              className={cn("rounded p-1.5 transition-colors", viewMode === "grid" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground")}
            >
              <Grid3X3 className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={cn("rounded p-1.5 transition-colors", viewMode === "list" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground")}
            >
              <List className="h-3.5 w-3.5" />
            </button>
          </div>
          <button className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground hover:border-primary hover:text-foreground transition-colors">
            <Filter className="h-3.5 w-3.5" /> Filter
          </button>
          <button className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground hover:border-primary hover:text-foreground transition-colors">
            <ArrowUpDown className="h-3.5 w-3.5" /> Sort by PSNR
          </button>
          <button className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground hover:border-primary hover:text-foreground transition-colors">
            <SlidersHorizontal className="h-3.5 w-3.5" /> Min PSNR: 28 dB
          </button>
          <div className="ml-auto">
            <button className="flex items-center gap-2 rounded-lg bg-primary/10 border border-primary/30 px-3 py-1.5 text-xs font-semibold text-primary hover:bg-primary/20 transition-colors">
              <Download className="h-3.5 w-3.5" /> Export All
            </button>
          </div>
        </div>

        {/* Gallery */}
        {viewMode === "grid" ? (
          <div className="grid grid-cols-3 gap-4">
            {beforeAfterPairs.map((pair) => (
              <div
                key={pair.id}
                className="group relative rounded-xl border border-border bg-card overflow-hidden hover:border-primary/50 transition-colors"
                onMouseEnter={() => setHoveredId(pair.id)}
                onMouseLeave={() => setHoveredId(null)}
              >
                {/* Image split */}
                <div className="relative h-40 overflow-hidden">
                  <img
                    src={hoveredId === pair.id ? pair.after : pair.before}
                    alt={pair.name}
                    className="h-full w-full object-cover transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute left-2 top-2 rounded-full border border-white/20 bg-black/50 px-2 py-0.5 text-[10px] font-medium text-white backdrop-blur-sm">
                    {hoveredId === pair.id ? "After →" : "Before"}
                  </div>
                  <div className="absolute right-2 top-2 flex items-center gap-1">
                    <button
                      onClick={() => toggleStar(pair.id)}
                      className={cn(
                        "rounded-full p-1 transition-colors backdrop-blur-sm",
                        starred.has(pair.id) ? "text-yellow-400" : "text-white/60 hover:text-yellow-400"
                      )}
                    >
                      <Star className={cn("h-3.5 w-3.5", starred.has(pair.id) && "fill-yellow-400")} />
                    </button>
                  </div>
                  <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 rounded-full bg-black/50 px-2 py-0.5 text-[10px] text-white backdrop-blur-sm">
                      <CloudOff className="h-2.5 w-2.5" />
                      {pair.cloudBefore}% → ~0%
                    </div>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="flex gap-2">
                      <button className="flex h-8 w-8 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur-sm hover:bg-primary/60 transition-colors">
                        <ZoomIn className="h-3.5 w-3.5" />
                      </button>
                      <button className="flex h-8 w-8 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur-sm hover:bg-primary/60 transition-colors">
                        <Download className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Metadata */}
                <div className="p-3">
                  <div className="mb-2 flex items-start justify-between gap-1">
                    <div>
                      <div className="text-xs font-semibold text-foreground leading-tight">{pair.name}</div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">{pair.date} · {pair.satellite}</div>
                    </div>
                    <span className="font-mono text-[10px] text-muted-foreground shrink-0">{pair.id}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-center">
                      <div className={cn(
                        "text-sm font-bold",
                        pair.psnr >= 35 ? "text-success" : pair.psnr >= 30 ? "text-primary" : "text-warning"
                      )}>
                        {pair.psnr.toFixed(2)}
                      </div>
                      <div className="text-[9px] text-muted-foreground">PSNR dB</div>
                    </div>
                    <div className="h-6 w-px bg-border" />
                    <div className="text-center">
                      <div className="text-sm font-bold text-chart-2">{pair.ssim.toFixed(3)}</div>
                      <div className="text-[9px] text-muted-foreground">SSIM</div>
                    </div>
                    <div className="ml-auto">
                      <button className="flex items-center gap-1 rounded-lg bg-primary/10 border border-primary/20 px-2 py-1 text-[10px] font-semibold text-primary hover:bg-primary/20 transition-colors">
                        <Download className="h-3 w-3" /> Export
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  {["Preview", "Scene ID", "Name", "Date", "Satellite", "Cloud Removed", "PSNR", "SSIM", "Actions"].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {beforeAfterPairs.map((pair) => (
                  <tr key={pair.id} className="hover:bg-muted/20 transition-colors group">
                    <td className="px-4 py-2.5">
                      <div className="h-10 w-16 overflow-hidden rounded-lg">
                        <img src={pair.after} alt="" className="h-full w-full object-cover" />
                      </div>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-xs text-muted-foreground">{pair.id}</td>
                    <td className="px-4 py-2.5 font-medium text-foreground">{pair.name}</td>
                    <td className="px-4 py-2.5 text-xs text-muted-foreground">{pair.date}</td>
                    <td className="px-4 py-2.5 text-xs text-muted-foreground">{pair.satellite}</td>
                    <td className="px-4 py-2.5 text-xs text-success">{pair.cloudBefore}% → ~0%</td>
                    <td className={cn("px-4 py-2.5 font-mono text-sm font-semibold", pair.psnr >= 35 ? "text-success" : pair.psnr >= 30 ? "text-primary" : "text-warning")}>
                      {pair.psnr.toFixed(2)} dB
                    </td>
                    <td className="px-4 py-2.5 font-mono text-sm text-chart-2">{pair.ssim.toFixed(3)}</td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="rounded p-1.5 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"><Eye className="h-3.5 w-3.5" /></button>
                        <button className="rounded p-1.5 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"><Download className="h-3.5 w-3.5" /></button>
                        <button onClick={() => toggleStar(pair.id)} className={cn("rounded p-1.5 transition-colors", starred.has(pair.id) ? "text-yellow-400" : "text-muted-foreground hover:text-yellow-400")}>
                          <Star className={cn("h-3.5 w-3.5", starred.has(pair.id) && "fill-yellow-400")} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Shell>
  );
}
