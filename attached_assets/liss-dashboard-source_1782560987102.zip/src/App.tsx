import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { DashboardPage } from "@/pages/dashboard";
import { DataManagerPage } from "@/pages/data-manager";
import { ProcessingPage } from "@/pages/processing";
import { ResultsPage } from "@/pages/results";
import { ComparisonPage } from "@/pages/comparison";
import { ReportsPage } from "@/pages/reports";
import { CloudDetectionPage } from "@/pages/cloud-detection";
import { ReconstructionPage } from "@/pages/reconstruction";
import { FusionPage } from "@/pages/fusion";
import { ModelManagerPage } from "@/pages/model-manager";
import { MonitoringPage } from "@/pages/monitoring";
import { SettingsPage } from "@/pages/settings";
import { StubPage } from "@/pages/stub";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={DashboardPage} />
      <Route path="/data-manager" component={DataManagerPage} />
      <Route path="/processing" component={ProcessingPage} />
      <Route path="/results" component={ResultsPage} />
      <Route path="/comparison" component={ComparisonPage} />
      <Route path="/reports" component={ReportsPage} />
      <Route path="/models/cloud-detection" component={CloudDetectionPage} />
      <Route path="/models/reconstruction" component={ReconstructionPage} />
      <Route path="/models/fusion" component={FusionPage} />
      <Route path="/models/manager" component={ModelManagerPage} />
      <Route path="/monitoring" component={MonitoringPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route>
        <StubPage title="Page Not Found" subtitle="This route does not exist" />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL?.replace(/\/$/, "") || ""}>
        <Router />
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
